globalThis.monorepoPackagePath = "";globalThis.openNextDebug = false;globalThis.openNextVersion = "4.1.4";globalThis.nextVersion = "16.3.6";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod3) => function __require2() {
  return mod3 || (0, cb[__getOwnPropNames(cb)[0]])((mod3 = { exports: {} }).exports, mod3), mod3.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod3, secondTarget) => (__copyProps(target, mod3, "default"), secondTarget && __copyProps(secondTarget, mod3, "default"));
var __toESM = (mod3, isNodeMode, target) => (target = mod3 != null ? __create(__getProtoOf(mod3)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod3 || !mod3.__esModule ? __defProp(target, "default", { value: mod3, enumerable: true }) : target,
  mod3
));
var __toCommonJS = (mod3) => __copyProps(__defProp({}, "__esModule", { value: true }), mod3);

// node_modules/@opennextjs/aws/dist/utils/error.js
function isOpenNextError(e) {
  try {
    return "__openNextInternal" in e;
  } catch {
    return false;
  }
}
var IgnorableError, FatalError;
var init_error = __esm({
  "node_modules/@opennextjs/aws/dist/utils/error.js"() {
    IgnorableError = class extends Error {
      __openNextInternal = true;
      canIgnore = true;
      logLevel = 0;
      constructor(message) {
        super(message);
        this.name = "IgnorableError";
      }
    };
    FatalError = class extends Error {
      __openNextInternal = true;
      canIgnore = false;
      logLevel = 2;
      constructor(message) {
        super(message);
        this.name = "FatalError";
      }
    };
  }
});

// node_modules/@opennextjs/aws/dist/adapters/logger.js
function debug(...args) {
  if (globalThis.openNextDebug) {
    console.log(...args);
  }
}
function warn(...args) {
  console.warn(...args);
}
function error(...args) {
  if (args.some((arg) => isDownplayedErrorLog(arg))) {
    return debug(...args);
  }
  if (args.some((arg) => isOpenNextError(arg))) {
    const error2 = args.find((arg) => isOpenNextError(arg));
    if (error2.logLevel < getOpenNextErrorLogLevel()) {
      return;
    }
    if (error2.logLevel === 0) {
      return console.log(...args.map((arg) => isOpenNextError(arg) ? `${arg.name}: ${arg.message}` : arg));
    }
    if (error2.logLevel === 1) {
      return warn(...args.map((arg) => isOpenNextError(arg) ? `${arg.name}: ${arg.message}` : arg));
    }
    return console.error(...args);
  }
  console.error(...args);
}
function getOpenNextErrorLogLevel() {
  const strLevel = process.env.OPEN_NEXT_ERROR_LOG_LEVEL ?? "1";
  switch (strLevel.toLowerCase()) {
    case "debug":
    case "0":
      return 0;
    case "error":
    case "2":
      return 2;
    default:
      return 1;
  }
}
var DOWNPLAYED_ERROR_LOGS, isDownplayedErrorLog;
var init_logger = __esm({
  "node_modules/@opennextjs/aws/dist/adapters/logger.js"() {
    init_error();
    DOWNPLAYED_ERROR_LOGS = [
      {
        clientName: "S3Client",
        commandName: "GetObjectCommand",
        errorName: "NoSuchKey"
      }
    ];
    isDownplayedErrorLog = (errorLog) => DOWNPLAYED_ERROR_LOGS.some((downplayedInput) => downplayedInput.clientName === errorLog?.clientName && downplayedInput.commandName === errorLog?.commandName && (downplayedInput.errorName === errorLog?.error?.name || downplayedInput.errorName === errorLog?.error?.Code));
  }
});

// node_modules/@opennextjs/aws/dist/http/util.js
function parseSetCookieHeader(cookies) {
  if (!cookies) {
    return [];
  }
  if (typeof cookies === "string") {
    return cookies.split(/(?<!Expires=\w+),/i).map((c) => c.trim());
  }
  return cookies;
}
function getQueryFromIterator(it) {
  const query = {};
  for (const [key, value] of it) {
    if (key in query) {
      if (Array.isArray(query[key])) {
        query[key].push(value);
      } else {
        query[key] = [query[key], value];
      }
    } else {
      query[key] = value;
    }
  }
  return query;
}
var parseHeaders, convertHeader;
var init_util = __esm({
  "node_modules/@opennextjs/aws/dist/http/util.js"() {
    init_logger();
    parseHeaders = (headers) => {
      const result = {};
      if (!headers) {
        return result;
      }
      for (const [key, value] of Object.entries(headers)) {
        if (value === void 0) {
          continue;
        }
        const keyLower = key.toLowerCase();
        if (keyLower === "location" && Array.isArray(value)) {
          if (value.length === 1 || value[0] === value[1]) {
            result[keyLower] = value[0];
          } else {
            warn("Multiple different values for Location header found. Using the last one");
            result[keyLower] = value[value.length - 1];
          }
          continue;
        }
        result[keyLower] = convertHeader(value);
      }
      return result;
    };
    convertHeader = (header) => {
      if (typeof header === "string") {
        return header;
      }
      if (Array.isArray(header)) {
        return header.join(",");
      }
      return String(header);
    };
  }
});

// node-built-in-modules:node:module
var node_module_exports = {};
import * as node_module_star from "node:module";
var init_node_module = __esm({
  "node-built-in-modules:node:module"() {
    __reExport(node_module_exports, node_module_star);
  }
});

// node_modules/@opennextjs/aws/dist/utils/stream.js
import { ReadableStream as ReadableStream2 } from "node:stream/web";
function emptyReadableStream() {
  if (process.env.OPEN_NEXT_FORCE_NON_EMPTY_RESPONSE === "true") {
    return new ReadableStream2({
      pull(controller) {
        maybeSomethingBuffer ??= Buffer.from("SOMETHING");
        controller.enqueue(maybeSomethingBuffer);
        controller.close();
      }
    }, { highWaterMark: 0 });
  }
  return new ReadableStream2({
    start(controller) {
      controller.close();
    }
  });
}
var maybeSomethingBuffer;
var init_stream = __esm({
  "node_modules/@opennextjs/aws/dist/utils/stream.js"() {
  }
});

// node_modules/@opennextjs/aws/dist/overrides/converters/utils.js
function getQueryFromSearchParams(searchParams) {
  return getQueryFromIterator(searchParams.entries());
}
var init_utils = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/converters/utils.js"() {
    init_util();
  }
});

// node_modules/cookie/dist/index.js
var require_dist = __commonJS({
  "node_modules/cookie/dist/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.parseCookie = parseCookie;
    exports.parse = parseCookie;
    exports.stringifyCookie = stringifyCookie;
    exports.stringifySetCookie = stringifySetCookie;
    exports.serialize = stringifySetCookie;
    exports.parseSetCookie = parseSetCookie;
    exports.stringifySetCookie = stringifySetCookie;
    exports.serialize = stringifySetCookie;
    var cookieNameRegExp = /^[\u0021-\u003A\u003C\u003E-\u007E]+$/;
    var cookieValueRegExp = /^[\u0021-\u003A\u003C-\u007E]*$/;
    var domainValueRegExp = /^([.]?[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i;
    var pathValueRegExp = /^[\u0020-\u003A\u003D-\u007E]*$/;
    var maxAgeRegExp = /^-?\d+$/;
    var __toString = Object.prototype.toString;
    var NullObject = /* @__PURE__ */ (() => {
      const C = function() {
      };
      C.prototype = /* @__PURE__ */ Object.create(null);
      return C;
    })();
    function parseCookie(str, options) {
      const obj = new NullObject();
      const len = str.length;
      if (len < 2)
        return obj;
      const dec = options?.decode || decode;
      let index = 0;
      do {
        const eqIdx = eqIndex(str, index, len);
        if (eqIdx === -1)
          break;
        const endIdx = endIndex(str, index, len);
        if (eqIdx > endIdx) {
          index = str.lastIndexOf(";", eqIdx - 1) + 1;
          continue;
        }
        const key = valueSlice(str, index, eqIdx);
        if (obj[key] === void 0) {
          obj[key] = dec(valueSlice(str, eqIdx + 1, endIdx));
        }
        index = endIdx + 1;
      } while (index < len);
      return obj;
    }
    function stringifyCookie(cookie, options) {
      const enc = options?.encode || encodeURIComponent;
      const cookieStrings = [];
      for (const name of Object.keys(cookie)) {
        const val = cookie[name];
        if (val === void 0)
          continue;
        if (!cookieNameRegExp.test(name)) {
          throw new TypeError(`cookie name is invalid: ${name}`);
        }
        const value = enc(val);
        if (!cookieValueRegExp.test(value)) {
          throw new TypeError(`cookie val is invalid: ${val}`);
        }
        cookieStrings.push(`${name}=${value}`);
      }
      return cookieStrings.join("; ");
    }
    function stringifySetCookie(_name, _val, _opts) {
      const cookie = typeof _name === "object" ? _name : { ..._opts, name: _name, value: String(_val) };
      const options = typeof _val === "object" ? _val : _opts;
      const enc = options?.encode || encodeURIComponent;
      if (!cookieNameRegExp.test(cookie.name)) {
        throw new TypeError(`argument name is invalid: ${cookie.name}`);
      }
      const value = cookie.value ? enc(cookie.value) : "";
      if (!cookieValueRegExp.test(value)) {
        throw new TypeError(`argument val is invalid: ${cookie.value}`);
      }
      let str = cookie.name + "=" + value;
      if (cookie.maxAge !== void 0) {
        if (!Number.isInteger(cookie.maxAge)) {
          throw new TypeError(`option maxAge is invalid: ${cookie.maxAge}`);
        }
        str += "; Max-Age=" + cookie.maxAge;
      }
      if (cookie.domain) {
        if (!domainValueRegExp.test(cookie.domain)) {
          throw new TypeError(`option domain is invalid: ${cookie.domain}`);
        }
        str += "; Domain=" + cookie.domain;
      }
      if (cookie.path) {
        if (!pathValueRegExp.test(cookie.path)) {
          throw new TypeError(`option path is invalid: ${cookie.path}`);
        }
        str += "; Path=" + cookie.path;
      }
      if (cookie.expires) {
        if (!isDate(cookie.expires) || !Number.isFinite(cookie.expires.valueOf())) {
          throw new TypeError(`option expires is invalid: ${cookie.expires}`);
        }
        str += "; Expires=" + cookie.expires.toUTCString();
      }
      if (cookie.httpOnly) {
        str += "; HttpOnly";
      }
      if (cookie.secure) {
        str += "; Secure";
      }
      if (cookie.partitioned) {
        str += "; Partitioned";
      }
      if (cookie.priority) {
        const priority = typeof cookie.priority === "string" ? cookie.priority.toLowerCase() : void 0;
        switch (priority) {
          case "low":
            str += "; Priority=Low";
            break;
          case "medium":
            str += "; Priority=Medium";
            break;
          case "high":
            str += "; Priority=High";
            break;
          default:
            throw new TypeError(`option priority is invalid: ${cookie.priority}`);
        }
      }
      if (cookie.sameSite) {
        const sameSite = typeof cookie.sameSite === "string" ? cookie.sameSite.toLowerCase() : cookie.sameSite;
        switch (sameSite) {
          case true:
          case "strict":
            str += "; SameSite=Strict";
            break;
          case "lax":
            str += "; SameSite=Lax";
            break;
          case "none":
            str += "; SameSite=None";
            break;
          default:
            throw new TypeError(`option sameSite is invalid: ${cookie.sameSite}`);
        }
      }
      return str;
    }
    function parseSetCookie(str, options) {
      const dec = options?.decode || decode;
      const len = str.length;
      const endIdx = endIndex(str, 0, len);
      const eqIdx = eqIndex(str, 0, endIdx);
      const setCookie = eqIdx === -1 ? { name: "", value: dec(valueSlice(str, 0, endIdx)) } : {
        name: valueSlice(str, 0, eqIdx),
        value: dec(valueSlice(str, eqIdx + 1, endIdx))
      };
      let index = endIdx + 1;
      while (index < len) {
        const endIdx2 = endIndex(str, index, len);
        const eqIdx2 = eqIndex(str, index, endIdx2);
        const attr = eqIdx2 === -1 ? valueSlice(str, index, endIdx2) : valueSlice(str, index, eqIdx2);
        const val = eqIdx2 === -1 ? void 0 : valueSlice(str, eqIdx2 + 1, endIdx2);
        switch (attr.toLowerCase()) {
          case "httponly":
            setCookie.httpOnly = true;
            break;
          case "secure":
            setCookie.secure = true;
            break;
          case "partitioned":
            setCookie.partitioned = true;
            break;
          case "domain":
            setCookie.domain = val;
            break;
          case "path":
            setCookie.path = val;
            break;
          case "max-age":
            if (val && maxAgeRegExp.test(val))
              setCookie.maxAge = Number(val);
            break;
          case "expires":
            if (!val)
              break;
            const date = new Date(val);
            if (Number.isFinite(date.valueOf()))
              setCookie.expires = date;
            break;
          case "priority":
            if (!val)
              break;
            const priority = val.toLowerCase();
            if (priority === "low" || priority === "medium" || priority === "high") {
              setCookie.priority = priority;
            }
            break;
          case "samesite":
            if (!val)
              break;
            const sameSite = val.toLowerCase();
            if (sameSite === "lax" || sameSite === "strict" || sameSite === "none") {
              setCookie.sameSite = sameSite;
            }
            break;
        }
        index = endIdx2 + 1;
      }
      return setCookie;
    }
    function endIndex(str, min, len) {
      const index = str.indexOf(";", min);
      return index === -1 ? len : index;
    }
    function eqIndex(str, min, max) {
      const index = str.indexOf("=", min);
      return index < max ? index : -1;
    }
    function valueSlice(str, min, max) {
      let start = min;
      let end = max;
      do {
        const code = str.charCodeAt(start);
        if (code !== 32 && code !== 9)
          break;
      } while (++start < end);
      while (end > start) {
        const code = str.charCodeAt(end - 1);
        if (code !== 32 && code !== 9)
          break;
        end--;
      }
      return str.slice(start, end);
    }
    function decode(str) {
      if (str.indexOf("%") === -1)
        return str;
      try {
        return decodeURIComponent(str);
      } catch (e) {
        return str;
      }
    }
    function isDate(val) {
      return __toString.call(val) === "[object Date]";
    }
  }
});

// node_modules/@opennextjs/aws/dist/overrides/converters/edge.js
var edge_exports = {};
__export(edge_exports, {
  default: () => edge_default
});
import { Buffer as Buffer2 } from "node:buffer";
var import_cookie, NULL_BODY_STATUSES, converter, edge_default;
var init_edge = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/converters/edge.js"() {
    import_cookie = __toESM(require_dist(), 1);
    init_util();
    init_utils();
    NULL_BODY_STATUSES = /* @__PURE__ */ new Set([101, 103, 204, 205, 304]);
    converter = {
      convertFrom: async (event) => {
        const url = new URL(event.url);
        const searchParams = url.searchParams;
        const query = getQueryFromSearchParams(searchParams);
        const headers = {};
        event.headers.forEach((value, key) => {
          headers[key] = value;
        });
        const rawPath = url.pathname;
        const method = event.method;
        const shouldHaveBody = method !== "GET" && method !== "HEAD";
        const body = shouldHaveBody ? Buffer2.from(await event.arrayBuffer()) : void 0;
        const cookieHeader = event.headers.get("cookie");
        const cookies = cookieHeader ? import_cookie.default.parse(cookieHeader) : {};
        return {
          type: "core",
          method,
          rawPath,
          url: event.url,
          body,
          headers,
          remoteAddress: event.headers.get("x-forwarded-for") ?? "::1",
          query,
          cookies
        };
      },
      convertTo: async (result) => {
        if ("internalEvent" in result) {
          const request = new Request(result.internalEvent.url, {
            body: result.internalEvent.body,
            method: result.internalEvent.method,
            headers: {
              ...result.internalEvent.headers,
              "x-forwarded-host": result.internalEvent.headers.host
            }
          });
          if (globalThis.__dangerous_ON_edge_converter_returns_request === true) {
            return request;
          }
          const cfCache = (result.isISR || result.internalEvent.rawPath.startsWith("/_next/image")) && process.env.DISABLE_CACHE !== "true" ? { cacheEverything: true } : {};
          return fetch(request, {
            // This is a hack to make sure that the response is cached by Cloudflare
            // See https://developers.cloudflare.com/workers/examples/cache-using-fetch/#caching-html-resources
            // @ts-expect-error - This is a Cloudflare specific option
            cf: cfCache
          });
        }
        const headers = new Headers();
        for (const [key, value] of Object.entries(result.headers)) {
          if (key === "set-cookie" && typeof value === "string") {
            const cookies = parseSetCookieHeader(value);
            for (const cookie of cookies) {
              headers.append(key, cookie);
            }
            continue;
          }
          if (Array.isArray(value)) {
            for (const v of value) {
              headers.append(key, v);
            }
          } else {
            headers.set(key, value);
          }
        }
        const body = NULL_BODY_STATUSES.has(result.statusCode) ? null : result.body;
        return new Response(body, {
          status: result.statusCode,
          headers
        });
      },
      name: "edge"
    };
    edge_default = converter;
  }
});

// node_modules/@opennextjs/aws/dist/overrides/wrappers/cloudflare-node.js
var cloudflare_node_exports = {};
__export(cloudflare_node_exports, {
  default: () => cloudflare_node_default
});
import { Writable } from "node:stream";
var NULL_BODY_STATUSES2, handler, cloudflare_node_default;
var init_cloudflare_node = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/wrappers/cloudflare-node.js"() {
    NULL_BODY_STATUSES2 = /* @__PURE__ */ new Set([101, 204, 205, 304]);
    handler = async (handler3, converter2) => async (request, env, ctx, abortSignal) => {
      globalThis.process = process;
      for (const [key, value] of Object.entries(env)) {
        if (typeof value === "string") {
          process.env[key] = value;
        }
      }
      const internalEvent = await converter2.convertFrom(request);
      const url = new URL(request.url);
      const { promise: promiseResponse, resolve: resolveResponse } = Promise.withResolvers();
      const streamCreator = {
        writeHeaders(prelude) {
          const { statusCode, cookies, headers } = prelude;
          const responseHeaders = new Headers(headers);
          for (const cookie of cookies) {
            responseHeaders.append("Set-Cookie", cookie);
          }
          if (url.hostname === "localhost") {
            responseHeaders.set("Content-Encoding", "identity");
          }
          if (NULL_BODY_STATUSES2.has(statusCode)) {
            const response2 = new Response(null, {
              status: statusCode,
              headers: responseHeaders
            });
            resolveResponse(response2);
            return new Writable({
              write(chunk, encoding, callback) {
                callback();
              }
            });
          }
          let controller;
          const readable = new ReadableStream({
            start(c) {
              controller = c;
            }
          });
          const response = new Response(readable, {
            status: statusCode,
            headers: responseHeaders
          });
          resolveResponse(response);
          return new Writable({
            write(chunk, encoding, callback) {
              try {
                controller.enqueue(chunk);
              } catch (e) {
                return callback(e);
              }
              callback();
            },
            final(callback) {
              controller.close();
              callback();
            },
            destroy(error2, callback) {
              if (error2) {
                controller.error(error2);
              } else {
                try {
                  controller.close();
                } catch {
                }
              }
              callback(error2);
            }
          });
        },
        // This is for passing along the original abort signal from the initial Request you retrieve in your worker
        // Ensures that the response we pass to NextServer is aborted if the request is aborted
        // By doing this `request.signal.onabort` will work in route handlers
        abortSignal,
        // There is no need to retain the chunks that were pushed to the response stream.
        retainChunks: false
      };
      ctx.waitUntil(handler3(internalEvent, {
        streamCreator,
        waitUntil: ctx.waitUntil.bind(ctx)
      }));
      return promiseResponse;
    };
    cloudflare_node_default = {
      wrapper: handler,
      name: "cloudflare-node",
      supportStreaming: true
    };
  }
});

// node_modules/@opennextjs/aws/dist/overrides/tagCache/dummy.js
var dummy_exports = {};
__export(dummy_exports, {
  default: () => dummy_default
});
var dummyTagCache, dummy_default;
var init_dummy = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/tagCache/dummy.js"() {
    dummyTagCache = {
      name: "dummy",
      mode: "original",
      getByPath: async () => {
        return [];
      },
      getByTag: async () => {
        return [];
      },
      getLastModified: async (_, lastModified) => {
        return lastModified ?? Date.now();
      },
      writeTags: async () => {
        return;
      },
      isStale: async (_path) => {
        return false;
      }
    };
    dummy_default = dummyTagCache;
  }
});

// node_modules/@opennextjs/aws/dist/overrides/queue/dummy.js
var dummy_exports2 = {};
__export(dummy_exports2, {
  default: () => dummy_default2
});
var dummyQueue, dummy_default2;
var init_dummy2 = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/queue/dummy.js"() {
    init_error();
    dummyQueue = {
      name: "dummy",
      send: async () => {
        throw new FatalError("Dummy queue is not implemented");
      }
    };
    dummy_default2 = dummyQueue;
  }
});

// node_modules/@opennextjs/aws/dist/overrides/incrementalCache/dummy.js
var dummy_exports3 = {};
__export(dummy_exports3, {
  default: () => dummy_default3
});
var dummyIncrementalCache, dummy_default3;
var init_dummy3 = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/incrementalCache/dummy.js"() {
    init_error();
    dummyIncrementalCache = {
      name: "dummy",
      get: async () => {
        throw new IgnorableError('"Dummy" cache does not cache anything');
      },
      set: async () => {
        throw new IgnorableError('"Dummy" cache does not cache anything');
      },
      delete: async () => {
        throw new IgnorableError('"Dummy" cache does not cache anything');
      }
    };
    dummy_default3 = dummyIncrementalCache;
  }
});

// node_modules/@opennextjs/aws/dist/overrides/assetResolver/dummy.js
var dummy_exports4 = {};
__export(dummy_exports4, {
  default: () => dummy_default4
});
var resolver, dummy_default4;
var init_dummy4 = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/assetResolver/dummy.js"() {
    resolver = {
      name: "dummy"
    };
    dummy_default4 = resolver;
  }
});

// node_modules/@opennextjs/aws/dist/overrides/proxyExternalRequest/fetch.js
var fetch_exports = {};
__export(fetch_exports, {
  default: () => fetch_default
});
var fetchProxy, fetch_default;
var init_fetch = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/proxyExternalRequest/fetch.js"() {
    init_stream();
    fetchProxy = {
      name: "fetch-proxy",
      // @ts-ignore
      proxy: async (internalEvent) => {
        const { url, headers: eventHeaders, method, body } = internalEvent;
        const headers = Object.fromEntries(Object.entries(eventHeaders).filter(([key]) => key.toLowerCase() !== "cf-connecting-ip"));
        const response = await fetch(url, {
          method,
          headers,
          body
        });
        const responseHeaders = {};
        response.headers.forEach((value, key) => {
          const cur = responseHeaders[key];
          if (cur === void 0) {
            responseHeaders[key] = value;
          } else if (Array.isArray(cur)) {
            cur.push(value);
          } else {
            responseHeaders[key] = [cur, value];
          }
        });
        return {
          type: "core",
          headers: responseHeaders,
          statusCode: response.status,
          isBase64Encoded: true,
          body: response.body ?? emptyReadableStream()
        };
      }
    };
    fetch_default = fetchProxy;
  }
});

// node_modules/@opennextjs/aws/dist/overrides/cdnInvalidation/dummy.js
var dummy_exports5 = {};
__export(dummy_exports5, {
  default: () => dummy_default5
});
var dummy_default5;
var init_dummy5 = __esm({
  "node_modules/@opennextjs/aws/dist/overrides/cdnInvalidation/dummy.js"() {
    dummy_default5 = {
      name: "dummy",
      invalidatePaths: (_) => {
        return Promise.resolve();
      }
    };
  }
});

// node_modules/@opennextjs/aws/dist/core/createMainHandler.js
init_logger();

// node_modules/@opennextjs/aws/dist/adapters/util.js
function setNodeEnv() {
  const processEnv = process.env;
  processEnv.NODE_ENV = process.env.NODE_ENV ?? "production";
}
function generateUniqueId() {
  return Math.random().toString(36).slice(2, 8);
}

// node_modules/@opennextjs/aws/dist/core/requestHandler.js
import { AsyncLocalStorage } from "node:async_hooks";

// node_modules/@opennextjs/aws/dist/http/openNextResponse.js
init_logger();
import { Transform } from "node:stream";

// node_modules/@opennextjs/aws/dist/utils/cacheHeaders.js
var CACHE_CONTROL_HEADER = "cache-control";
var NEXTJS_CACHE_HEADER = "x-nextjs-cache";
var ISR_HEADER = "x-isr";
var NO_STORE_CACHE_CONTROL = "private, no-cache, no-store, max-age=0, must-revalidate";
function fixCacheControlForError(headers, statusCode) {
  if (process.env.OPEN_NEXT_DANGEROUSLY_SET_ERROR_HEADERS === "true") {
    return;
  }
  if (statusCode === 404 || statusCode === 500) {
    headers[CACHE_CONTROL_HEADER] = NO_STORE_CACHE_CONTROL;
  }
}

// node_modules/@opennextjs/aws/dist/http/openNextResponse.js
init_util();
var SET_COOKIE_HEADER = "set-cookie";
var CANNOT_BE_USED = "This cannot be used in OpenNext";
var OpenNextNodeResponse = class extends Transform {
  fixHeadersFn;
  onEnd;
  streamCreator;
  initialHeaders;
  statusCode;
  statusMessage = "";
  headers = {};
  headersSent = false;
  _chunks = [];
  headersAlreadyFixed = false;
  _cookies = [];
  responseStream;
  bodyLength = 0;
  // To comply with the ServerResponse interface :
  strictContentLength = false;
  assignSocket(_socket) {
    throw new Error(CANNOT_BE_USED);
  }
  detachSocket(_socket) {
    throw new Error(CANNOT_BE_USED);
  }
  // We might have to revisit those 3 in the future
  writeContinue(_callback) {
    throw new Error(CANNOT_BE_USED);
  }
  writeEarlyHints(_hints, _callback) {
    throw new Error(CANNOT_BE_USED);
  }
  writeProcessing() {
    throw new Error(CANNOT_BE_USED);
  }
  /**
   * This is a dummy request object to comply with the ServerResponse interface
   * It will never be defined
   */
  req;
  chunkedEncoding = false;
  shouldKeepAlive = true;
  useChunkedEncodingByDefault = true;
  sendDate = false;
  connection = null;
  socket = null;
  setTimeout(_msecs, _callback) {
    throw new Error(CANNOT_BE_USED);
  }
  addTrailers(_headers) {
    throw new Error(CANNOT_BE_USED);
  }
  constructor(fixHeadersFn, onEnd, streamCreator, initialHeaders, statusCode) {
    super();
    this.fixHeadersFn = fixHeadersFn;
    this.onEnd = onEnd;
    this.streamCreator = streamCreator;
    this.initialHeaders = initialHeaders;
    if (statusCode && Number.isInteger(statusCode) && statusCode >= 100 && statusCode <= 599) {
      this.statusCode = statusCode;
    }
    streamCreator?.abortSignal?.addEventListener("abort", () => {
      this.destroy();
    });
  }
  // Necessary for next 12
  // We might have to implement all the methods here
  get originalResponse() {
    return this;
  }
  get finished() {
    return this.responseStream ? this.responseStream?.writableFinished : this.writableFinished;
  }
  setHeader(name, value) {
    const key = name.toLowerCase();
    if (key === SET_COOKIE_HEADER) {
      if (Array.isArray(value)) {
        this._cookies = value;
      } else {
        this._cookies = [value];
      }
    }
    this.headers[key] = value;
    return this;
  }
  removeHeader(name) {
    const key = name.toLowerCase();
    if (key === SET_COOKIE_HEADER) {
      this._cookies = [];
    } else {
      delete this.headers[key];
    }
    return this;
  }
  hasHeader(name) {
    const key = name.toLowerCase();
    if (key === SET_COOKIE_HEADER) {
      return this._cookies.length > 0;
    }
    return this.headers[key] !== void 0;
  }
  getHeaders() {
    return this.headers;
  }
  getHeader(name) {
    return this.headers[name.toLowerCase()];
  }
  getHeaderNames() {
    return Object.keys(this.headers);
  }
  // Only used directly in next@14+
  flushHeaders() {
    this.headersSent = true;
    const mergeHeadersPriority = globalThis.__openNextAls?.getStore()?.mergeHeadersPriority ?? "middleware";
    if (this.initialHeaders) {
      this.headers = mergeHeadersPriority === "middleware" ? {
        ...this.headers,
        ...this.initialHeaders
      } : {
        ...this.initialHeaders,
        ...this.headers
      };
      const initialCookies = parseSetCookieHeader(this.initialHeaders[SET_COOKIE_HEADER]?.toString());
      this._cookies = mergeHeadersPriority === "middleware" ? [...this._cookies, ...initialCookies] : [...initialCookies, ...this._cookies];
    }
    this.fixHeaders(this.headers);
    this.fixHeadersForError();
    this.headers[SET_COOKIE_HEADER] = this._cookies;
    const parsedHeaders = parseHeaders(this.headers);
    delete parsedHeaders[SET_COOKIE_HEADER];
    if (this.streamCreator) {
      this.responseStream = this.streamCreator?.writeHeaders({
        statusCode: this.statusCode ?? 200,
        cookies: this._cookies,
        headers: parsedHeaders
      });
      this.pipe(this.responseStream);
    }
  }
  appendHeader(name, value) {
    const key = name.toLowerCase();
    if (!this.hasHeader(key)) {
      return this.setHeader(key, value);
    }
    const existingHeader = this.getHeader(key);
    const toAppend = Array.isArray(value) ? value : [value];
    const newValue = Array.isArray(existingHeader) ? [...existingHeader, ...toAppend] : [existingHeader, ...toAppend];
    return this.setHeader(key, newValue);
  }
  writeHead(statusCode, statusMessage, headers) {
    let _headers = headers;
    let _statusMessage;
    if (typeof statusMessage === "string") {
      _statusMessage = statusMessage;
    } else {
      _headers = statusMessage;
    }
    const finalHeaders = this.headers;
    if (_headers) {
      if (Array.isArray(_headers)) {
        for (let i = 0; i < _headers.length; i += 2) {
          finalHeaders[_headers[i]] = _headers[i + 1];
        }
      } else {
        for (const key of Object.keys(_headers)) {
          finalHeaders[key] = _headers[key];
        }
      }
    }
    this.statusCode = statusCode;
    if (headers) {
      this.headers = finalHeaders;
    }
    this.flushHeaders();
    return this;
  }
  /**
   * OpenNext specific method
   */
  fixHeaders(headers) {
    if (this.headersAlreadyFixed) {
      return;
    }
    this.fixHeadersFn(headers);
    this.headersAlreadyFixed = true;
  }
  getFixedHeaders() {
    this.fixHeaders(this.headers);
    this.fixHeadersForError();
    this.headers[SET_COOKIE_HEADER] = this._cookies;
    return this.headers;
  }
  getBody() {
    return Buffer.concat(this._chunks);
  }
  _internalWrite(chunk, encoding) {
    const buffer = encoding === "buffer" ? chunk : Buffer.from(chunk, encoding);
    this.bodyLength += buffer.length;
    if (this.streamCreator?.retainChunks !== false) {
      this._chunks.push(buffer);
    }
    this.push(buffer);
    this.streamCreator?.onWrite?.();
  }
  _transform(chunk, encoding, callback) {
    if (!this.headersSent) {
      this.flushHeaders();
    }
    this._internalWrite(chunk, encoding);
    callback();
  }
  _flush(callback) {
    if (!this.headersSent) {
      this.flushHeaders();
    }
    globalThis.__openNextAls?.getStore()?.pendingPromiseRunner.add(this.onEnd(this.headers));
    this.streamCreator?.onFinish?.(this.bodyLength);
    if (this.bodyLength === 0 && // We use an env variable here because not all aws account have the same behavior
    // On some aws accounts the response will hang if the body is empty
    // We are modifying the response body here, this is not a good practice
    process.env.OPEN_NEXT_FORCE_NON_EMPTY_RESPONSE === "true") {
      debug('Force writing "SOMETHING" to the response body');
      this.push("SOMETHING");
    }
    callback();
  }
  /**
   * New method in Node 18.15+
   * There are probably not used right now in Next.js, but better be safe than sorry
   */
  setHeaders(headers) {
    headers.forEach((value, key) => {
      this.setHeader(key, Array.isArray(value) ? value : value.toString());
    });
    return this;
  }
  /**
   * Next specific methods
   * On earlier versions of next.js, those methods are mandatory to make everything work
   */
  get sent() {
    return this.finished || this.headersSent;
  }
  getHeaderValues(name) {
    const values = this.getHeader(name);
    if (values === void 0)
      return void 0;
    return (Array.isArray(values) ? values : [values]).map((value) => value.toString());
  }
  send() {
    for (const chunk of this._chunks) {
      this.write(chunk);
    }
    this.end();
  }
  body(value) {
    this.write(value);
    return this;
  }
  onClose(callback) {
    this.on("close", callback);
  }
  redirect(destination, statusCode) {
    this.setHeader("Location", destination);
    this.statusCode = statusCode;
    if (statusCode === 308) {
      this.setHeader("Refresh", `0;url=${destination}`);
    }
    return this;
  }
  // For some reason, next returns the 500 error page with some cache-control headers
  // We need to fix that
  fixHeadersForError() {
    fixCacheControlForError(this.headers, this.statusCode);
  }
};

// node_modules/@opennextjs/aws/dist/http/request.js
import http from "node:http";
var IncomingMessage = class extends http.IncomingMessage {
  constructor({ method, url, headers, body, remoteAddress }) {
    super({
      encrypted: true,
      readable: false,
      remoteAddress,
      address: () => ({ port: 443 }),
      end: Function.prototype,
      destroy: Function.prototype
    });
    if (body) {
      headers["content-length"] ??= String(Buffer.byteLength(body));
    }
    Object.assign(this, {
      ip: remoteAddress,
      complete: true,
      httpVersion: "1.1",
      httpVersionMajor: "1",
      httpVersionMinor: "1",
      method,
      headers,
      body,
      url
    });
    this._read = () => {
      this.push(body);
      this.push(null);
    };
  }
};

// node_modules/@opennextjs/aws/dist/utils/promise.js
init_logger();

// node_modules/@opennextjs/aws/dist/utils/requestCache.js
var RequestCache = class {
  _caches = /* @__PURE__ */ new Map();
  /**
   * Returns the Map registered under `key`.
   * If no Map exists yet for that key, a new empty Map is created, stored, and returned.
   * Repeated calls with the same key always return the **same** Map instance.
   */
  getOrCreate(key) {
    let cache = this._caches.get(key);
    if (!cache) {
      cache = /* @__PURE__ */ new Map();
      this._caches.set(key, cache);
    }
    return cache;
  }
};

// node_modules/@opennextjs/aws/dist/utils/promise.js
var DetachedPromise = class {
  resolve;
  reject;
  promise;
  constructor() {
    let resolve;
    let reject;
    this.promise = new Promise((res, rej) => {
      resolve = res;
      reject = rej;
    });
    this.resolve = resolve;
    this.reject = reject;
  }
};
var DetachedPromiseRunner = class {
  promises = [];
  withResolvers() {
    const detachedPromise = new DetachedPromise();
    this.promises.push(detachedPromise);
    return detachedPromise;
  }
  add(promise) {
    const detachedPromise = new DetachedPromise();
    this.promises.push(detachedPromise);
    promise.then(detachedPromise.resolve, detachedPromise.reject);
  }
  async await() {
    debug(`Awaiting ${this.promises.length} detached promises`);
    const results = await Promise.allSettled(this.promises.map((p) => p.promise));
    const rejectedPromises = results.filter((r) => r.status === "rejected");
    rejectedPromises.forEach((r) => {
      error(r.reason);
    });
  }
};
async function awaitAllDetachedPromise() {
  const store = globalThis.__openNextAls.getStore();
  const promisesToAwait = store?.pendingPromiseRunner.await() ?? Promise.resolve();
  if (store?.waitUntil) {
    store.waitUntil(promisesToAwait);
    return;
  }
  await promisesToAwait;
}
function provideNextAfterProvider() {
  const NEXT_REQUEST_CONTEXT_SYMBOL = Symbol.for("@next/request-context");
  const VERCEL_REQUEST_CONTEXT_SYMBOL = Symbol.for("@vercel/request-context");
  const store = globalThis.__openNextAls.getStore();
  const waitUntil = store?.waitUntil ?? ((promise) => store?.pendingPromiseRunner.add(promise));
  const nextAfterContext = {
    get: () => ({
      waitUntil
    })
  };
  globalThis[NEXT_REQUEST_CONTEXT_SYMBOL] = nextAfterContext;
  if (process.env.EMULATE_VERCEL_REQUEST_CONTEXT) {
    globalThis[VERCEL_REQUEST_CONTEXT_SYMBOL] = nextAfterContext;
  }
}
function runWithOpenNextRequestContext({ isISRRevalidation, waitUntil, requestId = Math.random().toString(36) }, fn) {
  return globalThis.__openNextAls.run({
    requestId,
    pendingPromiseRunner: new DetachedPromiseRunner(),
    isISRRevalidation,
    waitUntil,
    writtenTags: /* @__PURE__ */ new Set(),
    requestCache: new RequestCache()
  }, async () => {
    provideNextAfterProvider();
    let result;
    try {
      result = await fn();
    } finally {
      await awaitAllDetachedPromise();
    }
    return result;
  });
}

// node_modules/@opennextjs/aws/dist/adapters/config/index.js
init_logger();
import path from "node:path";
globalThis.__dirname ??= "";
var NEXT_DIR = path.join(__dirname, ".next");
var OPEN_NEXT_DIR = path.join(__dirname, ".open-next");
debug({ NEXT_DIR, OPEN_NEXT_DIR });
var NextConfig = { "env": {}, "typescript": { "ignoreBuildErrors": false }, "typedRoutes": false, "distDir": ".next", "cleanDistDir": true, "assetPrefix": "", "cacheMaxMemorySize": 52428800, "configOrigin": "next.config.mjs", "useFileSystemPublicRoutes": true, "generateEtags": true, "pageExtensions": ["tsx", "ts", "jsx", "js"], "instrumentationClientInject": [], "poweredByHeader": true, "compress": true, "images": { "deviceSizes": [640, 750, 828, 1080, 1200, 1920, 2048, 3840], "imageSizes": [32, 48, 64, 96, 128, 256, 384], "path": "/_next/image", "loader": "default", "loaderFile": "", "domains": [], "disableStaticImages": false, "minimumCacheTTL": 14400, "formats": ["image/webp"], "maximumRedirects": 3, "maximumResponseBody": 5e7, "dangerouslyAllowLocalIP": false, "dangerouslyAllowSVG": false, "contentSecurityPolicy": "script-src 'none'; frame-src 'none'; sandbox;", "contentDispositionType": "attachment", "localPatterns": [{ "pathname": "**", "search": "" }], "remotePatterns": [], "qualities": [75], "unoptimized": true, "customCacheHandler": false }, "devIndicators": { "position": "bottom-left" }, "onDemandEntries": { "maxInactiveAge": 6e4, "pagesBufferLength": 5 }, "basePath": "", "sassOptions": {}, "trailingSlash": false, "i18n": null, "productionBrowserSourceMaps": false, "excludeDefaultMomentLocales": true, "reactProductionProfiling": false, "reactStrictMode": null, "reactMaxHeadersLength": 6e3, "httpAgentOptions": { "keepAlive": true }, "logging": { "serverFunctions": true, "browserToTerminal": "warn" }, "compiler": {}, "expireTime": 31536e3, "staticPageGenerationTimeout": 60, "output": "standalone", "modularizeImports": { "@mui/icons-material": { "transform": "@mui/icons-material/{{member}}" }, "lodash": { "transform": "lodash/{{member}}" } }, "outputFileTracingRoot": "/home/user/jb-router-next", "enablePrerenderSourceMaps": true, "cacheComponents": false, "cacheLife": { "default": { "stale": 300, "revalidate": 900, "expire": 4294967294 }, "seconds": { "stale": 30, "revalidate": 1, "expire": 60 }, "minutes": { "stale": 300, "revalidate": 60, "expire": 3600 }, "hours": { "stale": 300, "revalidate": 3600, "expire": 86400 }, "days": { "stale": 300, "revalidate": 86400, "expire": 604800 }, "weeks": { "stale": 300, "revalidate": 604800, "expire": 2592e3 }, "max": { "stale": 300, "revalidate": 2592e3, "expire": 31536e3 } }, "cacheHandlers": {}, "experimental": { "appNewScrollHandler": true, "coldCacheBadge": false, "devValidationWorker": true, "useSkewCookie": false, "cssChunking": true, "multiZoneDraftMode": false, "appNavFailHandling": false, "prerenderEarlyExit": true, "serverMinification": true, "linkNoTouchStart": false, "caseSensitiveRoutes": false, "cachedNavigations": false, "dynamicOnHover": false, "useOffline": false, "varyParams": true, "optimisticRouting": true, "instrumentationClientRouterTransitionEvents": false, "prefetchInlining": { "maxSize": 2048, "maxBundleSize": 10240 }, "preloadEntriesOnStart": true, "clientRouterFilter": true, "clientRouterFilterRedirects": false, "fetchCacheKeyPrefix": "", "proxyPrefetch": "flexible", "optimisticClientCache": true, "manualClientBasePath": false, "cpus": 1, "memoryBasedWorkersCount": false, "imgOptConcurrency": null, "imgOptOperationCache": null, "imgOptTimeoutInSeconds": 7, "imgOptMaxInputPixels": 268402689, "imgOptSequentialRead": null, "isrFlushToDisk": true, "workerThreads": false, "optimizeCss": false, "nextScriptWorkers": false, "scrollRestoration": false, "externalDir": false, "devMemoryThresholdRestart": true, "disableOptimizedLoading": false, "gzipSize": true, "craCompat": false, "esmExternals": true, "fullySpecified": false, "swcTraceProfiling": false, "forceSwcTransforms": false, "requestInsights": false, "largePageDataBytes": 128e3, "typedEnv": false, "parallelServerCompiles": false, "parallelServerBuildTraces": false, "ppr": false, "authInterrupts": false, "webpackMemoryOptimizations": true, "optimizeServerReact": true, "strictRouteTypes": false, "useTypeScriptCli": true, "removeUncaughtErrorAndRejectionListeners": false, "validateRSCRequestHeaders": true, "staleTimes": { "dynamic": 0, "static": 300 }, "reactDebugChannel": true, "serverComponentsHmrCache": true, "serverComponentsHmrCancellation": false, "staticGenerationMaxConcurrency": 8, "staticGenerationMinPagesPerWorker": 25, "transitionIndicator": false, "gestureTransition": false, "inlineCss": false, "useCache": false, "globalNotFound": false, "browserDebugInfoInTerminal": "warn", "lockDistDir": true, "proxyClientMaxBodySize": 134217728, "hideLogsAfterAbort": false, "mcpServer": true, "turbopackFileSystemCacheForDev": true, "turbopackFileSystemCacheForBuild": true, "turbopackInferModuleSideEffects": true, "turbopackPluginRuntimeStrategy": "childProcesses", "optimizePackageImports": ["@xyflow/react", "@dnd-kit/core", "@dnd-kit/sortable", "material-symbols", "marked", "lucide-react", "date-fns", "lodash-es", "ramda", "antd", "react-bootstrap", "ahooks", "@ant-design/icons", "@headlessui/react", "@headlessui-float/react", "@heroicons/react/20/solid", "@heroicons/react/24/solid", "@heroicons/react/24/outline", "@visx/visx", "@tremor/react", "rxjs", "@mui/material", "@mui/icons-material", "recharts", "react-use", "effect", "@effect/schema", "@effect/platform", "@effect/platform-node", "@effect/platform-browser", "@effect/platform-bun", "@effect/sql", "@effect/sql-mssql", "@effect/sql-mysql2", "@effect/sql-pg", "@effect/sql-sqlite-node", "@effect/sql-sqlite-bun", "@effect/sql-sqlite-wasm", "@effect/sql-sqlite-react-native", "@effect/rpc", "@effect/rpc-http", "@effect/typeclass", "@effect/experimental", "@effect/opentelemetry", "@material-ui/core", "@material-ui/icons", "@tabler/icons-react", "mui-core", "react-icons/ai", "react-icons/bi", "react-icons/bs", "react-icons/cg", "react-icons/ci", "react-icons/di", "react-icons/fa", "react-icons/fa6", "react-icons/fc", "react-icons/fi", "react-icons/gi", "react-icons/go", "react-icons/gr", "react-icons/hi", "react-icons/hi2", "react-icons/im", "react-icons/io", "react-icons/io5", "react-icons/lia", "react-icons/lib", "react-icons/lu", "react-icons/md", "react-icons/pi", "react-icons/ri", "react-icons/rx", "react-icons/si", "react-icons/sl", "react-icons/tb", "react-icons/tfi", "react-icons/ti", "react-icons/vsc", "react-icons/wi"], "turbopackMemoryEvictionMode": "auto", "useCacheTimeout": 54, "instantInsights": { "validationLevel": "warning" }, "trustHostHeader": false, "isExperimentalCompile": false }, "htmlLimitedBots": "[\\w-]+-Google|Google-[\\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight", "bundlePagesRouterDependencies": false, "configFileName": "next.config.mjs", "serverExternalPackages": ["better-sqlite3", "sql.js", "node:sqlite", "bun:sqlite", "open"], "turbopack": { "root": "/home/user/jb-router-next" }, "outputFileTracingExcludes": { "*": ["./gitbook/**/*"] }, "repoRoot": "/home/user/jb-router-next", "distDirRoot": ".next", "supportsImmutableAssets": false, "_originalRewrites": { "beforeFiles": [], "afterFiles": [{ "source": "/v1/v1/:path*", "destination": "/api/v1/:path*" }, { "source": "/v1/v1", "destination": "/api/v1" }, { "source": "/codex/:path*", "destination": "/api/v1/responses" }, { "source": "/responses", "destination": "/api/v1/responses" }, { "source": "/systemone", "destination": "/api/v1/systemone" }, { "source": "/v1beta/:path*", "destination": "/api/v1beta/:path*" }, { "source": "/v1beta", "destination": "/api/v1beta" }, { "source": "/v1/:path*", "destination": "/api/v1/:path*" }, { "source": "/v1", "destination": "/api/v1" }], "fallback": [] } };
var BuildId = "4WVTrqHGQNhCwhipluz5Q";
var HtmlPages = ["/404", "/500"];
var RoutesManifest = { "basePath": "", "rewrites": { "beforeFiles": [], "afterFiles": [{ "source": "/v1/v1/:path*", "destination": "/api/v1/:path*", "regex": "^/v1/v1(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))?(?:/)?$" }, { "source": "/v1/v1", "destination": "/api/v1", "regex": "^/v1/v1(?:/)?$" }, { "source": "/codex/:path*", "destination": "/api/v1/responses", "regex": "^/codex(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))?(?:/)?$" }, { "source": "/responses", "destination": "/api/v1/responses", "regex": "^/responses(?:/)?$" }, { "source": "/systemone", "destination": "/api/v1/systemone", "regex": "^/systemone(?:/)?$" }, { "source": "/v1beta/:path*", "destination": "/api/v1beta/:path*", "regex": "^/v1beta(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))?(?:/)?$" }, { "source": "/v1beta", "destination": "/api/v1beta", "regex": "^/v1beta(?:/)?$" }, { "source": "/v1/:path*", "destination": "/api/v1/:path*", "regex": "^/v1(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))?(?:/)?$" }, { "source": "/v1", "destination": "/api/v1", "regex": "^/v1(?:/)?$" }], "fallback": [] }, "redirects": [{ "source": "/:path+/", "destination": "/:path+", "internal": true, "priority": true, "statusCode": 308, "regex": "^(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))/$" }], "routes": { "static": [{ "page": "/", "regex": "^/(?:/)?$", "routeKeys": {}, "namedRegex": "^/(?:/)?$" }, { "page": "/_global-error", "regex": "^/_global\\-error(?:/)?$", "routeKeys": {}, "namedRegex": "^/_global\\-error(?:/)?$" }, { "page": "/_not-found", "regex": "^/_not\\-found(?:/)?$", "routeKeys": {}, "namedRegex": "^/_not\\-found(?:/)?$" }, { "page": "/api/auth/login", "regex": "^/api/auth/login(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/login(?:/)?$" }, { "page": "/api/auth/logout", "regex": "^/api/auth/logout(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/logout(?:/)?$" }, { "page": "/api/auth/oidc/callback", "regex": "^/api/auth/oidc/callback(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/oidc/callback(?:/)?$" }, { "page": "/api/auth/oidc/start", "regex": "^/api/auth/oidc/start(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/oidc/start(?:/)?$" }, { "page": "/api/auth/oidc/test", "regex": "^/api/auth/oidc/test(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/oidc/test(?:/)?$" }, { "page": "/api/auth/reset-password", "regex": "^/api/auth/reset\\-password(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/reset\\-password(?:/)?$" }, { "page": "/api/auth/saml/acs", "regex": "^/api/auth/saml/acs(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/saml/acs(?:/)?$" }, { "page": "/api/auth/saml/metadata", "regex": "^/api/auth/saml/metadata(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/saml/metadata(?:/)?$" }, { "page": "/api/auth/saml/start", "regex": "^/api/auth/saml/start(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/saml/start(?:/)?$" }, { "page": "/api/auth/saml/test", "regex": "^/api/auth/saml/test(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/saml/test(?:/)?$" }, { "page": "/api/auth/status", "regex": "^/api/auth/status(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/auth/status(?:/)?$" }, { "page": "/api/cli-tools/all-statuses", "regex": "^/api/cli\\-tools/all\\-statuses(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/all\\-statuses(?:/)?$" }, { "page": "/api/cli-tools/antigravity-mitm", "regex": "^/api/cli\\-tools/antigravity\\-mitm(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/antigravity\\-mitm(?:/)?$" }, { "page": "/api/cli-tools/antigravity-mitm/alias", "regex": "^/api/cli\\-tools/antigravity\\-mitm/alias(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/antigravity\\-mitm/alias(?:/)?$" }, { "page": "/api/cli-tools/claude-settings", "regex": "^/api/cli\\-tools/claude\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/claude\\-settings(?:/)?$" }, { "page": "/api/cli-tools/cline-settings", "regex": "^/api/cli\\-tools/cline\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/cline\\-settings(?:/)?$" }, { "page": "/api/cli-tools/codewhale-settings", "regex": "^/api/cli\\-tools/codewhale\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/codewhale\\-settings(?:/)?$" }, { "page": "/api/cli-tools/codex-settings", "regex": "^/api/cli\\-tools/codex\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/codex\\-settings(?:/)?$" }, { "page": "/api/cli-tools/copilot-settings", "regex": "^/api/cli\\-tools/copilot\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/copilot\\-settings(?:/)?$" }, { "page": "/api/cli-tools/cowork-mcp-registry", "regex": "^/api/cli\\-tools/cowork\\-mcp\\-registry(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/cowork\\-mcp\\-registry(?:/)?$" }, { "page": "/api/cli-tools/cowork-mcp-tools", "regex": "^/api/cli\\-tools/cowork\\-mcp\\-tools(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/cowork\\-mcp\\-tools(?:/)?$" }, { "page": "/api/cli-tools/cowork-settings", "regex": "^/api/cli\\-tools/cowork\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/cowork\\-settings(?:/)?$" }, { "page": "/api/cli-tools/crush-settings", "regex": "^/api/cli\\-tools/crush\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/crush\\-settings(?:/)?$" }, { "page": "/api/cli-tools/deepseek-tui-settings", "regex": "^/api/cli\\-tools/deepseek\\-tui\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/deepseek\\-tui\\-settings(?:/)?$" }, { "page": "/api/cli-tools/devin-settings", "regex": "^/api/cli\\-tools/devin\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/devin\\-settings(?:/)?$" }, { "page": "/api/cli-tools/droid-settings", "regex": "^/api/cli\\-tools/droid\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/droid\\-settings(?:/)?$" }, { "page": "/api/cli-tools/forge-settings", "regex": "^/api/cli\\-tools/forge\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/forge\\-settings(?:/)?$" }, { "page": "/api/cli-tools/grok-build-settings", "regex": "^/api/cli\\-tools/grok\\-build\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/grok\\-build\\-settings(?:/)?$" }, { "page": "/api/cli-tools/hermes-settings", "regex": "^/api/cli\\-tools/hermes\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/hermes\\-settings(?:/)?$" }, { "page": "/api/cli-tools/jcode-settings", "regex": "^/api/cli\\-tools/jcode\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/jcode\\-settings(?:/)?$" }, { "page": "/api/cli-tools/kilo-settings", "regex": "^/api/cli\\-tools/kilo\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/kilo\\-settings(?:/)?$" }, { "page": "/api/cli-tools/omp-settings", "regex": "^/api/cli\\-tools/omp\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/omp\\-settings(?:/)?$" }, { "page": "/api/cli-tools/openclaw-settings", "regex": "^/api/cli\\-tools/openclaw\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/openclaw\\-settings(?:/)?$" }, { "page": "/api/cli-tools/opencode-settings", "regex": "^/api/cli\\-tools/opencode\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/opencode\\-settings(?:/)?$" }, { "page": "/api/cli-tools/pi-settings", "regex": "^/api/cli\\-tools/pi\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/pi\\-settings(?:/)?$" }, { "page": "/api/cli-tools/smelt-settings", "regex": "^/api/cli\\-tools/smelt\\-settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/cli\\-tools/smelt\\-settings(?:/)?$" }, { "page": "/api/combos", "regex": "^/api/combos(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/combos(?:/)?$" }, { "page": "/api/combos/presets", "regex": "^/api/combos/presets(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/combos/presets(?:/)?$" }, { "page": "/api/headroom/extras", "regex": "^/api/headroom/extras(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/headroom/extras(?:/)?$" }, { "page": "/api/headroom/restart", "regex": "^/api/headroom/restart(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/headroom/restart(?:/)?$" }, { "page": "/api/headroom/start", "regex": "^/api/headroom/start(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/headroom/start(?:/)?$" }, { "page": "/api/headroom/status", "regex": "^/api/headroom/status(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/headroom/status(?:/)?$" }, { "page": "/api/headroom/stop", "regex": "^/api/headroom/stop(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/headroom/stop(?:/)?$" }, { "page": "/api/health", "regex": "^/api/health(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/health(?:/)?$" }, { "page": "/api/init", "regex": "^/api/init(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/init(?:/)?$" }, { "page": "/api/keys", "regex": "^/api/keys(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/keys(?:/)?$" }, { "page": "/api/locale", "regex": "^/api/locale(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/locale(?:/)?$" }, { "page": "/api/media-providers/tts/deepgram/voices", "regex": "^/api/media\\-providers/tts/deepgram/voices(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/media\\-providers/tts/deepgram/voices(?:/)?$" }, { "page": "/api/media-providers/tts/elevenlabs/voices", "regex": "^/api/media\\-providers/tts/elevenlabs/voices(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/media\\-providers/tts/elevenlabs/voices(?:/)?$" }, { "page": "/api/media-providers/tts/inworld/voices", "regex": "^/api/media\\-providers/tts/inworld/voices(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/media\\-providers/tts/inworld/voices(?:/)?$" }, { "page": "/api/media-providers/tts/minimax/voices", "regex": "^/api/media\\-providers/tts/minimax/voices(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/media\\-providers/tts/minimax/voices(?:/)?$" }, { "page": "/api/media-providers/tts/voices", "regex": "^/api/media\\-providers/tts/voices(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/media\\-providers/tts/voices(?:/)?$" }, { "page": "/api/models", "regex": "^/api/models(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/models(?:/)?$" }, { "page": "/api/models/alias", "regex": "^/api/models/alias(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/models/alias(?:/)?$" }, { "page": "/api/models/availability", "regex": "^/api/models/availability(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/models/availability(?:/)?$" }, { "page": "/api/models/catalog-sync", "regex": "^/api/models/catalog\\-sync(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/models/catalog\\-sync(?:/)?$" }, { "page": "/api/models/custom", "regex": "^/api/models/custom(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/models/custom(?:/)?$" }, { "page": "/api/models/disabled", "regex": "^/api/models/disabled(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/models/disabled(?:/)?$" }, { "page": "/api/models/test", "regex": "^/api/models/test(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/models/test(?:/)?$" }, { "page": "/api/oauth/codex/bulk-import", "regex": "^/api/oauth/codex/bulk\\-import(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/codex/bulk\\-import(?:/)?$" }, { "page": "/api/oauth/codex/import-token", "regex": "^/api/oauth/codex/import\\-token(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/codex/import\\-token(?:/)?$" }, { "page": "/api/oauth/cursor/auto-import", "regex": "^/api/oauth/cursor/auto\\-import(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/cursor/auto\\-import(?:/)?$" }, { "page": "/api/oauth/cursor/import", "regex": "^/api/oauth/cursor/import(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/cursor/import(?:/)?$" }, { "page": "/api/oauth/gitlab/pat", "regex": "^/api/oauth/gitlab/pat(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/gitlab/pat(?:/)?$" }, { "page": "/api/oauth/grok-cli/bulk-import", "regex": "^/api/oauth/grok\\-cli/bulk\\-import(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/grok\\-cli/bulk\\-import(?:/)?$" }, { "page": "/api/oauth/iflow/cookie", "regex": "^/api/oauth/iflow/cookie(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/iflow/cookie(?:/)?$" }, { "page": "/api/oauth/kiro/api-key", "regex": "^/api/oauth/kiro/api\\-key(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/kiro/api\\-key(?:/)?$" }, { "page": "/api/oauth/kiro/auto-import", "regex": "^/api/oauth/kiro/auto\\-import(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/kiro/auto\\-import(?:/)?$" }, { "page": "/api/oauth/kiro/import", "regex": "^/api/oauth/kiro/import(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/kiro/import(?:/)?$" }, { "page": "/api/oauth/kiro/import-cli-proxy", "regex": "^/api/oauth/kiro/import\\-cli\\-proxy(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/kiro/import\\-cli\\-proxy(?:/)?$" }, { "page": "/api/oauth/kiro/social-authorize", "regex": "^/api/oauth/kiro/social\\-authorize(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/kiro/social\\-authorize(?:/)?$" }, { "page": "/api/oauth/kiro/social-exchange", "regex": "^/api/oauth/kiro/social\\-exchange(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/kiro/social\\-exchange(?:/)?$" }, { "page": "/api/oauth/xiaomi-mimo/api-key", "regex": "^/api/oauth/xiaomi\\-mimo/api\\-key(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/xiaomi\\-mimo/api\\-key(?:/)?$" }, { "page": "/api/oauth/xiaomi-mimo/auto-import", "regex": "^/api/oauth/xiaomi\\-mimo/auto\\-import(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/xiaomi\\-mimo/auto\\-import(?:/)?$" }, { "page": "/api/oauth/xiaomi-mimo/login/start", "regex": "^/api/oauth/xiaomi\\-mimo/login/start(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/xiaomi\\-mimo/login/start(?:/)?$" }, { "page": "/api/oauth/xiaomi-mimo/login/status", "regex": "^/api/oauth/xiaomi\\-mimo/login/status(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/oauth/xiaomi\\-mimo/login/status(?:/)?$" }, { "page": "/api/pricing", "regex": "^/api/pricing(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pricing(?:/)?$" }, { "page": "/api/provider-nodes", "regex": "^/api/provider\\-nodes(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/provider\\-nodes(?:/)?$" }, { "page": "/api/provider-nodes/validate", "regex": "^/api/provider\\-nodes/validate(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/provider\\-nodes/validate(?:/)?$" }, { "page": "/api/providers", "regex": "^/api/providers(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/providers(?:/)?$" }, { "page": "/api/providers/client", "regex": "^/api/providers/client(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/providers/client(?:/)?$" }, { "page": "/api/providers/kilo/free-models", "regex": "^/api/providers/kilo/free\\-models(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/providers/kilo/free\\-models(?:/)?$" }, { "page": "/api/providers/suggested-models", "regex": "^/api/providers/suggested\\-models(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/providers/suggested\\-models(?:/)?$" }, { "page": "/api/providers/test-batch", "regex": "^/api/providers/test\\-batch(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/providers/test\\-batch(?:/)?$" }, { "page": "/api/providers/validate", "regex": "^/api/providers/validate(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/providers/validate(?:/)?$" }, { "page": "/api/proxy-pools", "regex": "^/api/proxy\\-pools(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/proxy\\-pools(?:/)?$" }, { "page": "/api/proxy-pools/cloudflare-deploy", "regex": "^/api/proxy\\-pools/cloudflare\\-deploy(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/proxy\\-pools/cloudflare\\-deploy(?:/)?$" }, { "page": "/api/proxy-pools/deno-deploy", "regex": "^/api/proxy\\-pools/deno\\-deploy(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/proxy\\-pools/deno\\-deploy(?:/)?$" }, { "page": "/api/proxy-pools/vercel-deploy", "regex": "^/api/proxy\\-pools/vercel\\-deploy(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/proxy\\-pools/vercel\\-deploy(?:/)?$" }, { "page": "/api/pxpipe/health", "regex": "^/api/pxpipe/health(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/health(?:/)?$" }, { "page": "/api/pxpipe/install", "regex": "^/api/pxpipe/install(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/install(?:/)?$" }, { "page": "/api/pxpipe/logs", "regex": "^/api/pxpipe/logs(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/logs(?:/)?$" }, { "page": "/api/pxpipe/restart", "regex": "^/api/pxpipe/restart(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/restart(?:/)?$" }, { "page": "/api/pxpipe/start", "regex": "^/api/pxpipe/start(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/start(?:/)?$" }, { "page": "/api/pxpipe/stats", "regex": "^/api/pxpipe/stats(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/stats(?:/)?$" }, { "page": "/api/pxpipe/status", "regex": "^/api/pxpipe/status(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/status(?:/)?$" }, { "page": "/api/pxpipe/stop", "regex": "^/api/pxpipe/stop(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/pxpipe/stop(?:/)?$" }, { "page": "/api/settings", "regex": "^/api/settings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/settings(?:/)?$" }, { "page": "/api/settings/database", "regex": "^/api/settings/database(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/settings/database(?:/)?$" }, { "page": "/api/settings/proxy-test", "regex": "^/api/settings/proxy\\-test(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/settings/proxy\\-test(?:/)?$" }, { "page": "/api/settings/require-login", "regex": "^/api/settings/require\\-login(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/settings/require\\-login(?:/)?$" }, { "page": "/api/shutdown", "regex": "^/api/shutdown(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/shutdown(?:/)?$" }, { "page": "/api/tags", "regex": "^/api/tags(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tags(?:/)?$" }, { "page": "/api/translator/console-logs", "regex": "^/api/translator/console\\-logs(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/translator/console\\-logs(?:/)?$" }, { "page": "/api/translator/console-logs/stream", "regex": "^/api/translator/console\\-logs/stream(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/translator/console\\-logs/stream(?:/)?$" }, { "page": "/api/translator/load", "regex": "^/api/translator/load(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/translator/load(?:/)?$" }, { "page": "/api/translator/save", "regex": "^/api/translator/save(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/translator/save(?:/)?$" }, { "page": "/api/translator/send", "regex": "^/api/translator/send(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/translator/send(?:/)?$" }, { "page": "/api/translator/translate", "regex": "^/api/translator/translate(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/translator/translate(?:/)?$" }, { "page": "/api/tunnel/disable", "regex": "^/api/tunnel/disable(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tunnel/disable(?:/)?$" }, { "page": "/api/tunnel/enable", "regex": "^/api/tunnel/enable(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tunnel/enable(?:/)?$" }, { "page": "/api/tunnel/status", "regex": "^/api/tunnel/status(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tunnel/status(?:/)?$" }, { "page": "/api/tunnel/tailscale-check", "regex": "^/api/tunnel/tailscale\\-check(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tunnel/tailscale\\-check(?:/)?$" }, { "page": "/api/tunnel/tailscale-disable", "regex": "^/api/tunnel/tailscale\\-disable(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tunnel/tailscale\\-disable(?:/)?$" }, { "page": "/api/tunnel/tailscale-enable", "regex": "^/api/tunnel/tailscale\\-enable(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tunnel/tailscale\\-enable(?:/)?$" }, { "page": "/api/tunnel/tailscale-install", "regex": "^/api/tunnel/tailscale\\-install(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/tunnel/tailscale\\-install(?:/)?$" }, { "page": "/api/usage/chart", "regex": "^/api/usage/chart(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/chart(?:/)?$" }, { "page": "/api/usage/history", "regex": "^/api/usage/history(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/history(?:/)?$" }, { "page": "/api/usage/logs", "regex": "^/api/usage/logs(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/logs(?:/)?$" }, { "page": "/api/usage/providers", "regex": "^/api/usage/providers(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/providers(?:/)?$" }, { "page": "/api/usage/request-details", "regex": "^/api/usage/request\\-details(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/request\\-details(?:/)?$" }, { "page": "/api/usage/request-logs", "regex": "^/api/usage/request\\-logs(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/request\\-logs(?:/)?$" }, { "page": "/api/usage/stats", "regex": "^/api/usage/stats(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/stats(?:/)?$" }, { "page": "/api/usage/stream", "regex": "^/api/usage/stream(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/usage/stream(?:/)?$" }, { "page": "/api/v1", "regex": "^/api/v1(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1(?:/)?$" }, { "page": "/api/v1/api/chat", "regex": "^/api/v1/api/chat(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/api/chat(?:/)?$" }, { "page": "/api/v1/audio/speech", "regex": "^/api/v1/audio/speech(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/audio/speech(?:/)?$" }, { "page": "/api/v1/audio/transcriptions", "regex": "^/api/v1/audio/transcriptions(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/audio/transcriptions(?:/)?$" }, { "page": "/api/v1/audio/voices", "regex": "^/api/v1/audio/voices(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/audio/voices(?:/)?$" }, { "page": "/api/v1/chat/completions", "regex": "^/api/v1/chat/completions(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/chat/completions(?:/)?$" }, { "page": "/api/v1/embeddings", "regex": "^/api/v1/embeddings(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/embeddings(?:/)?$" }, { "page": "/api/v1/images/generations", "regex": "^/api/v1/images/generations(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/images/generations(?:/)?$" }, { "page": "/api/v1/messages", "regex": "^/api/v1/messages(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/messages(?:/)?$" }, { "page": "/api/v1/messages/count_tokens", "regex": "^/api/v1/messages/count_tokens(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/messages/count_tokens(?:/)?$" }, { "page": "/api/v1/models", "regex": "^/api/v1/models(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/models(?:/)?$" }, { "page": "/api/v1/models/info", "regex": "^/api/v1/models/info(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/models/info(?:/)?$" }, { "page": "/api/v1/responses", "regex": "^/api/v1/responses(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/responses(?:/)?$" }, { "page": "/api/v1/responses/compact", "regex": "^/api/v1/responses/compact(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/responses/compact(?:/)?$" }, { "page": "/api/v1/search", "regex": "^/api/v1/search(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/search(?:/)?$" }, { "page": "/api/v1/systemone", "regex": "^/api/v1/systemone(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/systemone(?:/)?$" }, { "page": "/api/v1/videos/edits", "regex": "^/api/v1/videos/edits(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/videos/edits(?:/)?$" }, { "page": "/api/v1/videos/extensions", "regex": "^/api/v1/videos/extensions(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/videos/extensions(?:/)?$" }, { "page": "/api/v1/videos/generations", "regex": "^/api/v1/videos/generations(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/videos/generations(?:/)?$" }, { "page": "/api/v1/web/fetch", "regex": "^/api/v1/web/fetch(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1/web/fetch(?:/)?$" }, { "page": "/api/v1beta/models", "regex": "^/api/v1beta/models(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/v1beta/models(?:/)?$" }, { "page": "/api/version", "regex": "^/api/version(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/version(?:/)?$" }, { "page": "/api/version/shutdown", "regex": "^/api/version/shutdown(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/version/shutdown(?:/)?$" }, { "page": "/api/version/update", "regex": "^/api/version/update(?:/)?$", "routeKeys": {}, "namedRegex": "^/api/version/update(?:/)?$" }, { "page": "/callback", "regex": "^/callback(?:/)?$", "routeKeys": {}, "namedRegex": "^/callback(?:/)?$" }, { "page": "/dashboard", "regex": "^/dashboard(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard(?:/)?$" }, { "page": "/dashboard/basic-chat", "regex": "^/dashboard/basic\\-chat(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/basic\\-chat(?:/)?$" }, { "page": "/dashboard/cli-tools", "regex": "^/dashboard/cli\\-tools(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/cli\\-tools(?:/)?$" }, { "page": "/dashboard/combos", "regex": "^/dashboard/combos(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/combos(?:/)?$" }, { "page": "/dashboard/console-log", "regex": "^/dashboard/console\\-log(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/console\\-log(?:/)?$" }, { "page": "/dashboard/endpoint", "regex": "^/dashboard/endpoint(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/endpoint(?:/)?$" }, { "page": "/dashboard/media-providers/web", "regex": "^/dashboard/media\\-providers/web(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/media\\-providers/web(?:/)?$" }, { "page": "/dashboard/mitm", "regex": "^/dashboard/mitm(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/mitm(?:/)?$" }, { "page": "/dashboard/profile", "regex": "^/dashboard/profile(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/profile(?:/)?$" }, { "page": "/dashboard/providers", "regex": "^/dashboard/providers(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/providers(?:/)?$" }, { "page": "/dashboard/providers/new", "regex": "^/dashboard/providers/new(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/providers/new(?:/)?$" }, { "page": "/dashboard/proxy-pools", "regex": "^/dashboard/proxy\\-pools(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/proxy\\-pools(?:/)?$" }, { "page": "/dashboard/pxpipe", "regex": "^/dashboard/pxpipe(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/pxpipe(?:/)?$" }, { "page": "/dashboard/quota", "regex": "^/dashboard/quota(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/quota(?:/)?$" }, { "page": "/dashboard/settings/pricing", "regex": "^/dashboard/settings/pricing(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/settings/pricing(?:/)?$" }, { "page": "/dashboard/skills", "regex": "^/dashboard/skills(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/skills(?:/)?$" }, { "page": "/dashboard/token-saver", "regex": "^/dashboard/token\\-saver(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/token\\-saver(?:/)?$" }, { "page": "/dashboard/translator", "regex": "^/dashboard/translator(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/translator(?:/)?$" }, { "page": "/dashboard/usage", "regex": "^/dashboard/usage(?:/)?$", "routeKeys": {}, "namedRegex": "^/dashboard/usage(?:/)?$" }, { "page": "/favicon.ico", "regex": "^/favicon\\.ico(?:/)?$", "routeKeys": {}, "namedRegex": "^/favicon\\.ico(?:/)?$" }, { "page": "/landing", "regex": "^/landing(?:/)?$", "routeKeys": {}, "namedRegex": "^/landing(?:/)?$" }, { "page": "/login", "regex": "^/login(?:/)?$", "routeKeys": {}, "namedRegex": "^/login(?:/)?$" }, { "page": "/manifest.webmanifest", "regex": "^/manifest\\.webmanifest(?:/)?$", "routeKeys": {}, "namedRegex": "^/manifest\\.webmanifest(?:/)?$" }], "dynamic": [{ "page": "/api/combos/[id]", "regex": "^/api/combos/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/combos/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/api/headroom/proxy/[...path]", "regex": "^/api/headroom/proxy/(.+?)(?:/)?$", "routeKeys": { "nxtPpath": "nxtPpath" }, "namedRegex": "^/api/headroom/proxy/(?<nxtPpath>.+?)(?:/)?$" }, { "page": "/api/keys/[id]", "regex": "^/api/keys/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/keys/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/api/mcp/[plugin]/message", "regex": "^/api/mcp/([^/]+?)/message(?:/)?$", "routeKeys": { "nxtPplugin": "nxtPplugin" }, "namedRegex": "^/api/mcp/(?<nxtPplugin>[^/]+?)/message(?:/)?$" }, { "page": "/api/mcp/[plugin]/sse", "regex": "^/api/mcp/([^/]+?)/sse(?:/)?$", "routeKeys": { "nxtPplugin": "nxtPplugin" }, "namedRegex": "^/api/mcp/(?<nxtPplugin>[^/]+?)/sse(?:/)?$" }, { "page": "/api/oauth/[provider]/[action]", "regex": "^/api/oauth/([^/]+?)/([^/]+?)(?:/)?$", "routeKeys": { "nxtPprovider": "nxtPprovider", "nxtPaction": "nxtPaction" }, "namedRegex": "^/api/oauth/(?<nxtPprovider>[^/]+?)/(?<nxtPaction>[^/]+?)(?:/)?$" }, { "page": "/api/provider-nodes/[id]", "regex": "^/api/provider\\-nodes/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/provider\\-nodes/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/api/providers/[id]", "regex": "^/api/providers/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/providers/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/api/providers/[id]/models", "regex": "^/api/providers/([^/]+?)/models(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/providers/(?<nxtPid>[^/]+?)/models(?:/)?$" }, { "page": "/api/providers/[id]/test", "regex": "^/api/providers/([^/]+?)/test(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/providers/(?<nxtPid>[^/]+?)/test(?:/)?$" }, { "page": "/api/providers/[id]/test-models", "regex": "^/api/providers/([^/]+?)/test\\-models(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/providers/(?<nxtPid>[^/]+?)/test\\-models(?:/)?$" }, { "page": "/api/proxy-pools/[id]", "regex": "^/api/proxy\\-pools/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/proxy\\-pools/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/api/proxy-pools/[id]/test", "regex": "^/api/proxy\\-pools/([^/]+?)/test(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/proxy\\-pools/(?<nxtPid>[^/]+?)/test(?:/)?$" }, { "page": "/api/usage/[connectionId]", "regex": "^/api/usage/([^/]+?)(?:/)?$", "routeKeys": { "nxtPconnectionId": "nxtPconnectionId" }, "namedRegex": "^/api/usage/(?<nxtPconnectionId>[^/]+?)(?:/)?$" }, { "page": "/api/usage/[connectionId]/codex-reset-credits", "regex": "^/api/usage/([^/]+?)/codex\\-reset\\-credits(?:/)?$", "routeKeys": { "nxtPconnectionId": "nxtPconnectionId" }, "namedRegex": "^/api/usage/(?<nxtPconnectionId>[^/]+?)/codex\\-reset\\-credits(?:/)?$" }, { "page": "/api/v1/models/[...model]", "regex": "^/api/v1/models/(.+?)(?:/)?$", "routeKeys": { "nxtPmodel": "nxtPmodel" }, "namedRegex": "^/api/v1/models/(?<nxtPmodel>.+?)(?:/)?$" }, { "page": "/api/v1/videos/[id]", "regex": "^/api/v1/videos/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/api/v1/videos/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/api/v1beta/models/[...path]", "regex": "^/api/v1beta/models/(.+?)(?:/)?$", "routeKeys": { "nxtPpath": "nxtPpath" }, "namedRegex": "^/api/v1beta/models/(?<nxtPpath>.+?)(?:/)?$" }, { "page": "/dashboard/cli-tools/[toolId]", "regex": "^/dashboard/cli\\-tools/([^/]+?)(?:/)?$", "routeKeys": { "nxtPtoolId": "nxtPtoolId" }, "namedRegex": "^/dashboard/cli\\-tools/(?<nxtPtoolId>[^/]+?)(?:/)?$" }, { "page": "/dashboard/media-providers/combo/[id]", "regex": "^/dashboard/media\\-providers/combo/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/dashboard/media\\-providers/combo/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/dashboard/media-providers/[kind]", "regex": "^/dashboard/media\\-providers/([^/]+?)(?:/)?$", "routeKeys": { "nxtPkind": "nxtPkind" }, "namedRegex": "^/dashboard/media\\-providers/(?<nxtPkind>[^/]+?)(?:/)?$" }, { "page": "/dashboard/media-providers/[kind]/[id]", "regex": "^/dashboard/media\\-providers/([^/]+?)/([^/]+?)(?:/)?$", "routeKeys": { "nxtPkind": "nxtPkind", "nxtPid": "nxtPid" }, "namedRegex": "^/dashboard/media\\-providers/(?<nxtPkind>[^/]+?)/(?<nxtPid>[^/]+?)(?:/)?$" }, { "page": "/dashboard/providers/[id]", "regex": "^/dashboard/providers/([^/]+?)(?:/)?$", "routeKeys": { "nxtPid": "nxtPid" }, "namedRegex": "^/dashboard/providers/(?<nxtPid>[^/]+?)(?:/)?$" }], "data": { "static": [], "dynamic": [] } }, "locales": [] };
var PrerenderManifest = { "version": 4, "routes": { "/": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 7394, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/", "dataRoute": "/index.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/_global-error": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 8999, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/_global-error", "dataRoute": "/_global-error.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/_not-found": { "initialStatus": 404, "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 10390, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/_not-found", "dataRoute": "/_not-found.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/callback": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 10294, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/callback", "dataRoute": "/callback.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 26533, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard", "dataRoute": "/dashboard.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/basic-chat": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 29160, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/basic-chat", "dataRoute": "/dashboard/basic-chat.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/cli-tools": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 29071, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/cli-tools", "dataRoute": "/dashboard/cli-tools.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/combos": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 27267, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/combos", "dataRoute": "/dashboard/combos.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/endpoint": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 27048, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/endpoint", "dataRoute": "/dashboard/endpoint.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/media-providers/web": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 48987, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/media-providers/web", "dataRoute": "/dashboard/media-providers/web.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/mitm": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 32169, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/mitm", "dataRoute": "/dashboard/mitm.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/profile": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 37493, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/profile", "dataRoute": "/dashboard/profile.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/providers": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 27158, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/providers", "dataRoute": "/dashboard/providers.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/providers/new": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 36844, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/providers/new", "dataRoute": "/dashboard/providers/new.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/proxy-pools": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 27217, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/proxy-pools", "dataRoute": "/dashboard/proxy-pools.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/pxpipe": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 31219, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/pxpipe", "dataRoute": "/dashboard/pxpipe.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/quota": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 33579, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/quota", "dataRoute": "/dashboard/quota.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/settings/pricing": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 13770, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/settings/pricing", "dataRoute": "/dashboard/settings/pricing.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/skills": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 40028, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/skills", "dataRoute": "/dashboard/skills.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/token-saver": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 30233, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/token-saver", "dataRoute": "/dashboard/token-saver.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/translator": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 36121, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/translator", "dataRoute": "/dashboard/translator.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/dashboard/usage": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 26767, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/dashboard/usage", "dataRoute": "/dashboard/usage.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/favicon.ico": { "initialHeaders": { "cache-control": "public, max-age=0, must-revalidate", "content-type": "image/x-icon", "x-next-cache-tags": "_N_T_/layout,_N_T_/favicon.ico/layout,_N_T_/favicon.ico/route,_N_T_/favicon.ico" }, "routeType": "route", "response": "complete", "compute": "static", "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/favicon.ico", "dataRoute": null, "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/landing": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 33798, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/landing", "dataRoute": "/landing.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/login": { "routeType": "page", "response": "complete", "compute": "static", "htmlSize": 10302, "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/login", "dataRoute": "/login.rsc", "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] }, "/manifest.webmanifest": { "initialHeaders": { "cache-control": "public, max-age=0, must-revalidate", "content-type": "application/manifest+json", "x-next-cache-tags": "_N_T_/layout,_N_T_/manifest.webmanifest/layout,_N_T_/manifest.webmanifest/route,_N_T_/manifest.webmanifest" }, "routeType": "route", "response": "complete", "compute": "static", "experimentalBypassFor": [{ "type": "header", "key": "next-action" }, { "type": "header", "key": "content-type", "value": "multipart/form-data;.*" }], "initialRevalidateSeconds": false, "srcRoute": "/manifest.webmanifest", "dataRoute": null, "allowHeader": ["host", "x-matched-path", "x-prerender-revalidate", "x-prerender-revalidate-if-generated", "x-next-revalidated-tags", "x-next-revalidate-tag-token"] } }, "dynamicRoutes": {}, "notFoundRoutes": [], "preview": { "previewModeId": "9c3f369ebd878519cb6426778726b2ee", "previewModeSigningKey": "83824b119ee1a91919df8945848e591145cba945b565ca3d431cfae7a2aeffab", "previewModeEncryptionKey": "faae7571cb1332521386bfae9f580a9bf0a46c8f175dd382951f137783791b27" } };
var MiddlewareManifest = { "version": 3, "middleware": {}, "functions": {}, "sortedMiddleware": [] };
var AppPathRoutesManifest = { "/_not-found/page": "/_not-found", "/_global-error/page": "/_global-error", "/api/auth/login/route": "/api/auth/login", "/api/auth/logout/route": "/api/auth/logout", "/api/auth/oidc/callback/route": "/api/auth/oidc/callback", "/api/auth/oidc/start/route": "/api/auth/oidc/start", "/api/auth/oidc/test/route": "/api/auth/oidc/test", "/api/auth/reset-password/route": "/api/auth/reset-password", "/api/auth/saml/acs/route": "/api/auth/saml/acs", "/api/auth/saml/metadata/route": "/api/auth/saml/metadata", "/api/auth/saml/start/route": "/api/auth/saml/start", "/api/auth/saml/test/route": "/api/auth/saml/test", "/api/auth/status/route": "/api/auth/status", "/api/cli-tools/all-statuses/route": "/api/cli-tools/all-statuses", "/api/cli-tools/antigravity-mitm/alias/route": "/api/cli-tools/antigravity-mitm/alias", "/api/cli-tools/antigravity-mitm/route": "/api/cli-tools/antigravity-mitm", "/api/cli-tools/claude-settings/route": "/api/cli-tools/claude-settings", "/api/cli-tools/cline-settings/route": "/api/cli-tools/cline-settings", "/api/cli-tools/codewhale-settings/route": "/api/cli-tools/codewhale-settings", "/api/cli-tools/codex-settings/route": "/api/cli-tools/codex-settings", "/api/cli-tools/copilot-settings/route": "/api/cli-tools/copilot-settings", "/api/cli-tools/cowork-mcp-registry/route": "/api/cli-tools/cowork-mcp-registry", "/api/cli-tools/cowork-mcp-tools/route": "/api/cli-tools/cowork-mcp-tools", "/api/cli-tools/cowork-settings/route": "/api/cli-tools/cowork-settings", "/api/cli-tools/crush-settings/route": "/api/cli-tools/crush-settings", "/api/cli-tools/deepseek-tui-settings/route": "/api/cli-tools/deepseek-tui-settings", "/api/cli-tools/droid-settings/route": "/api/cli-tools/droid-settings", "/api/cli-tools/forge-settings/route": "/api/cli-tools/forge-settings", "/api/cli-tools/grok-build-settings/route": "/api/cli-tools/grok-build-settings", "/api/cli-tools/hermes-settings/route": "/api/cli-tools/hermes-settings", "/api/cli-tools/jcode-settings/route": "/api/cli-tools/jcode-settings", "/api/cli-tools/kilo-settings/route": "/api/cli-tools/kilo-settings", "/api/cli-tools/openclaw-settings/route": "/api/cli-tools/openclaw-settings", "/api/cli-tools/opencode-settings/route": "/api/cli-tools/opencode-settings", "/api/cli-tools/pi-settings/route": "/api/cli-tools/pi-settings", "/api/cli-tools/smelt-settings/route": "/api/cli-tools/smelt-settings", "/api/combos/[id]/route": "/api/combos/[id]", "/api/health/route": "/api/health", "/api/init/route": "/api/init", "/api/keys/[id]/route": "/api/keys/[id]", "/api/locale/route": "/api/locale", "/api/media-providers/tts/deepgram/voices/route": "/api/media-providers/tts/deepgram/voices", "/api/media-providers/tts/elevenlabs/voices/route": "/api/media-providers/tts/elevenlabs/voices", "/api/media-providers/tts/inworld/voices/route": "/api/media-providers/tts/inworld/voices", "/api/media-providers/tts/minimax/voices/route": "/api/media-providers/tts/minimax/voices", "/api/media-providers/tts/voices/route": "/api/media-providers/tts/voices", "/api/models/availability/route": "/api/models/availability", "/api/models/catalog-sync/route": "/api/models/catalog-sync", "/api/models/route": "/api/models", "/api/models/test/route": "/api/models/test", "/api/oauth/codex/bulk-import/route": "/api/oauth/codex/bulk-import", "/api/oauth/codex/import-token/route": "/api/oauth/codex/import-token", "/api/oauth/cursor/auto-import/route": "/api/oauth/cursor/auto-import", "/api/oauth/cursor/import/route": "/api/oauth/cursor/import", "/api/oauth/gitlab/pat/route": "/api/oauth/gitlab/pat", "/api/oauth/grok-cli/bulk-import/route": "/api/oauth/grok-cli/bulk-import", "/api/oauth/iflow/cookie/route": "/api/oauth/iflow/cookie", "/api/oauth/kiro/api-key/route": "/api/oauth/kiro/api-key", "/api/oauth/kiro/import/route": "/api/oauth/kiro/import", "/api/oauth/kiro/social-authorize/route": "/api/oauth/kiro/social-authorize", "/api/oauth/kiro/social-exchange/route": "/api/oauth/kiro/social-exchange", "/api/oauth/xiaomi-mimo/api-key/route": "/api/oauth/xiaomi-mimo/api-key", "/api/oauth/xiaomi-mimo/auto-import/route": "/api/oauth/xiaomi-mimo/auto-import", "/api/pricing/route": "/api/pricing", "/api/provider-nodes/[id]/route": "/api/provider-nodes/[id]", "/api/provider-nodes/validate/route": "/api/provider-nodes/validate", "/api/providers/[id]/test-models/route": "/api/providers/[id]/test-models", "/api/providers/[id]/test/route": "/api/providers/[id]/test", "/api/providers/kilo/free-models/route": "/api/providers/kilo/free-models", "/api/providers/test-batch/route": "/api/providers/test-batch", "/api/providers/validate/route": "/api/providers/validate", "/api/settings/require-login/route": "/api/settings/require-login", "/api/shutdown/route": "/api/shutdown", "/api/tags/route": "/api/tags", "/api/translator/console-logs/route": "/api/translator/console-logs", "/api/translator/load/route": "/api/translator/load", "/api/translator/save/route": "/api/translator/save", "/api/translator/send/route": "/api/translator/send", "/api/translator/translate/route": "/api/translator/translate", "/api/tunnel/disable/route": "/api/tunnel/disable", "/api/tunnel/enable/route": "/api/tunnel/enable", "/api/tunnel/status/route": "/api/tunnel/status", "/api/tunnel/tailscale-check/route": "/api/tunnel/tailscale-check", "/api/tunnel/tailscale-disable/route": "/api/tunnel/tailscale-disable", "/api/tunnel/tailscale-enable/route": "/api/tunnel/tailscale-enable", "/api/tunnel/tailscale-install/route": "/api/tunnel/tailscale-install", "/api/usage/chart/route": "/api/usage/chart", "/api/usage/history/route": "/api/usage/history", "/api/usage/logs/route": "/api/usage/logs", "/api/usage/providers/route": "/api/usage/providers", "/api/usage/request-details/route": "/api/usage/request-details", "/api/usage/request-logs/route": "/api/usage/request-logs", "/api/v1/api/chat/route": "/api/v1/api/chat", "/api/v1/audio/speech/route": "/api/v1/audio/speech", "/api/v1/audio/voices/route": "/api/v1/audio/voices", "/api/v1/chat/completions/route": "/api/v1/chat/completions", "/api/v1/embeddings/route": "/api/v1/embeddings", "/api/v1/images/generations/route": "/api/v1/images/generations", "/api/v1/messages/count_tokens/route": "/api/v1/messages/count_tokens", "/api/v1/messages/route": "/api/v1/messages", "/api/v1/models/[...model]/route": "/api/v1/models/[...model]", "/api/v1/models/info/route": "/api/v1/models/info", "/api/v1/responses/compact/route": "/api/v1/responses/compact", "/api/v1/responses/route": "/api/v1/responses", "/api/v1/route": "/api/v1", "/api/v1/search/route": "/api/v1/search", "/api/v1/systemone/route": "/api/v1/systemone", "/api/v1/videos/[id]/route": "/api/v1/videos/[id]", "/api/v1/videos/edits/route": "/api/v1/videos/edits", "/api/v1/videos/extensions/route": "/api/v1/videos/extensions", "/api/v1/videos/generations/route": "/api/v1/videos/generations", "/api/v1/web/fetch/route": "/api/v1/web/fetch", "/api/v1beta/models/route": "/api/v1beta/models", "/api/version/route": "/api/version", "/api/version/shutdown/route": "/api/version/shutdown", "/api/version/update/route": "/api/version/update", "/favicon.ico/route": "/favicon.ico", "/manifest.webmanifest/route": "/manifest.webmanifest", "/api/cli-tools/devin-settings/route": "/api/cli-tools/devin-settings", "/api/cli-tools/omp-settings/route": "/api/cli-tools/omp-settings", "/api/combos/presets/route": "/api/combos/presets", "/api/combos/route": "/api/combos", "/api/headroom/extras/route": "/api/headroom/extras", "/api/headroom/proxy/[...path]/route": "/api/headroom/proxy/[...path]", "/api/headroom/restart/route": "/api/headroom/restart", "/api/headroom/status/route": "/api/headroom/status", "/api/headroom/stop/route": "/api/headroom/stop", "/api/headroom/start/route": "/api/headroom/start", "/api/keys/route": "/api/keys", "/api/mcp/[plugin]/message/route": "/api/mcp/[plugin]/message", "/api/mcp/[plugin]/sse/route": "/api/mcp/[plugin]/sse", "/api/models/alias/route": "/api/models/alias", "/api/models/disabled/route": "/api/models/disabled", "/api/models/custom/route": "/api/models/custom", "/api/oauth/[provider]/[action]/route": "/api/oauth/[provider]/[action]", "/api/oauth/kiro/auto-import/route": "/api/oauth/kiro/auto-import", "/api/oauth/kiro/import-cli-proxy/route": "/api/oauth/kiro/import-cli-proxy", "/api/oauth/xiaomi-mimo/login/start/route": "/api/oauth/xiaomi-mimo/login/start", "/api/oauth/xiaomi-mimo/login/status/route": "/api/oauth/xiaomi-mimo/login/status", "/api/provider-nodes/route": "/api/provider-nodes", "/api/providers/[id]/route": "/api/providers/[id]", "/api/providers/[id]/models/route": "/api/providers/[id]/models", "/api/providers/client/route": "/api/providers/client", "/api/providers/route": "/api/providers", "/api/providers/suggested-models/route": "/api/providers/suggested-models", "/api/proxy-pools/[id]/route": "/api/proxy-pools/[id]", "/api/proxy-pools/[id]/test/route": "/api/proxy-pools/[id]/test", "/api/proxy-pools/cloudflare-deploy/route": "/api/proxy-pools/cloudflare-deploy", "/api/proxy-pools/deno-deploy/route": "/api/proxy-pools/deno-deploy", "/api/proxy-pools/route": "/api/proxy-pools", "/api/proxy-pools/vercel-deploy/route": "/api/proxy-pools/vercel-deploy", "/api/pxpipe/health/route": "/api/pxpipe/health", "/api/pxpipe/install/route": "/api/pxpipe/install", "/api/pxpipe/logs/route": "/api/pxpipe/logs", "/api/pxpipe/restart/route": "/api/pxpipe/restart", "/api/pxpipe/start/route": "/api/pxpipe/start", "/api/pxpipe/stats/route": "/api/pxpipe/stats", "/api/pxpipe/status/route": "/api/pxpipe/status", "/api/pxpipe/stop/route": "/api/pxpipe/stop", "/api/settings/database/route": "/api/settings/database", "/api/settings/proxy-test/route": "/api/settings/proxy-test", "/api/settings/route": "/api/settings", "/api/translator/console-logs/stream/route": "/api/translator/console-logs/stream", "/api/usage/[connectionId]/codex-reset-credits/route": "/api/usage/[connectionId]/codex-reset-credits", "/api/usage/[connectionId]/route": "/api/usage/[connectionId]", "/api/usage/stats/route": "/api/usage/stats", "/api/v1/audio/transcriptions/route": "/api/v1/audio/transcriptions", "/api/usage/stream/route": "/api/usage/stream", "/api/v1/models/route": "/api/v1/models", "/api/v1beta/models/[...path]/route": "/api/v1beta/models/[...path]", "/callback/page": "/callback", "/dashboard/settings/pricing/page": "/dashboard/settings/pricing", "/landing/page": "/landing", "/login/page": "/login", "/page": "/", "/(dashboard)/dashboard/basic-chat/page": "/dashboard/basic-chat", "/(dashboard)/dashboard/cli-tools/[toolId]/page": "/dashboard/cli-tools/[toolId]", "/(dashboard)/dashboard/cli-tools/page": "/dashboard/cli-tools", "/(dashboard)/dashboard/combos/page": "/dashboard/combos", "/(dashboard)/dashboard/endpoint/page": "/dashboard/endpoint", "/(dashboard)/dashboard/media-providers/[kind]/[id]/page": "/dashboard/media-providers/[kind]/[id]", "/(dashboard)/dashboard/media-providers/[kind]/page": "/dashboard/media-providers/[kind]", "/(dashboard)/dashboard/media-providers/combo/[id]/page": "/dashboard/media-providers/combo/[id]", "/(dashboard)/dashboard/media-providers/web/page": "/dashboard/media-providers/web", "/(dashboard)/dashboard/mitm/page": "/dashboard/mitm", "/(dashboard)/dashboard/page": "/dashboard", "/(dashboard)/dashboard/providers/new/page": "/dashboard/providers/new", "/(dashboard)/dashboard/pxpipe/page": "/dashboard/pxpipe", "/(dashboard)/dashboard/quota/page": "/dashboard/quota", "/(dashboard)/dashboard/skills/page": "/dashboard/skills", "/(dashboard)/dashboard/token-saver/page": "/dashboard/token-saver", "/(dashboard)/dashboard/translator/page": "/dashboard/translator", "/(dashboard)/dashboard/usage/page": "/dashboard/usage", "/(dashboard)/dashboard/console-log/page": "/dashboard/console-log", "/(dashboard)/dashboard/providers/page": "/dashboard/providers", "/(dashboard)/dashboard/providers/[id]/page": "/dashboard/providers/[id]", "/(dashboard)/dashboard/proxy-pools/page": "/dashboard/proxy-pools", "/(dashboard)/dashboard/profile/page": "/dashboard/profile" };
var FunctionsConfigManifest = { "version": 1, "functions": { "/_middleware": { "runtime": "nodejs", "matchers": [{ "regexp": "^(?:\\/(_next\\/data\\/[^/]{1,}))?(?:\\/((?!_next\\/static|_next\\/image|favicon\\.ico).*))(\\.json|\\.rsc|\\.segments\\/.+\\.segment\\.rsc)?[\\/#\\?]?$", "originalSource": "/((?!_next/static|_next/image|favicon\\.ico).*)" }] }, "/api/mcp/[plugin]/message": {}, "/api/mcp/[plugin]/sse": {}, "/api/pxpipe/install": { "maxDuration": 300 }, "/api/pxpipe/start": { "maxDuration": 300 }, "/api/v1/audio/transcriptions": { "maxDuration": 300 } } };
var PagesManifest = { "/404": "pages/404.html", "/500": "pages/500.html" };
process.env.NEXT_BUILD_ID = BuildId;
process.env.OPEN_NEXT_BUILD_ID = NextConfig.deploymentId ?? BuildId;
process.env.NEXT_PREVIEW_MODE_ID = PrerenderManifest?.preview?.previewModeId;

// node_modules/@opennextjs/aws/dist/core/requestHandler.js
init_logger();

// node_modules/@opennextjs/aws/dist/core/patchAsyncStorage.js
var mod = (init_node_module(), __toCommonJS(node_module_exports));
var resolveFilename = mod._resolveFilename;

// node_modules/@opennextjs/aws/dist/core/routing/util.js
import crypto from "node:crypto";
init_util();
init_logger();
import { ReadableStream as ReadableStream3 } from "node:stream/web";

// node_modules/@opennextjs/aws/dist/utils/binary.js
var commonBinaryMimeTypes = /* @__PURE__ */ new Set([
  "application/octet-stream",
  // Docs
  "application/epub+zip",
  "application/msword",
  "application/pdf",
  "application/rtf",
  "application/vnd.amazon.ebook",
  "application/vnd.ms-excel",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  // Fonts
  "font/otf",
  "font/woff",
  "font/woff2",
  // Images
  "image/bmp",
  "image/gif",
  "image/jpeg",
  "image/png",
  "image/tiff",
  "image/vnd.microsoft.icon",
  "image/webp",
  // Audio
  "audio/3gpp",
  "audio/aac",
  "audio/basic",
  "audio/flac",
  "audio/mpeg",
  "audio/ogg",
  "audio/wavaudio/webm",
  "audio/x-aiff",
  "audio/x-midi",
  "audio/x-wav",
  // Video
  "video/3gpp",
  "video/mp2t",
  "video/mpeg",
  "video/ogg",
  "video/quicktime",
  "video/webm",
  "video/x-msvideo",
  // Archives
  "application/java-archive",
  "application/vnd.apple.installer+xml",
  "application/x-7z-compressed",
  "application/x-apple-diskimage",
  "application/x-bzip",
  "application/x-bzip2",
  "application/x-gzip",
  "application/x-java-archive",
  "application/x-rar-compressed",
  "application/x-tar",
  "application/x-zip",
  "application/zip",
  // Serialized data
  "application/x-protobuf"
]);
function isBinaryContentType(contentType) {
  if (!contentType)
    return false;
  const value = contentType.split(";")[0];
  return commonBinaryMimeTypes.has(value);
}

// node_modules/@opennextjs/aws/dist/core/routing/i18n/index.js
init_stream();
init_logger();

// node_modules/@opennextjs/aws/dist/core/routing/i18n/accept-header.js
function parse(raw, preferences, options) {
  const lowers = /* @__PURE__ */ new Map();
  const header = raw.replace(/[ \t]/g, "");
  if (preferences) {
    let pos = 0;
    for (const preference of preferences) {
      const lower = preference.toLowerCase();
      lowers.set(lower, { orig: preference, pos: pos++ });
      if (options.prefixMatch) {
        const parts2 = lower.split("-");
        while (parts2.pop(), parts2.length > 0) {
          const joined = parts2.join("-");
          if (!lowers.has(joined)) {
            lowers.set(joined, { orig: preference, pos: pos++ });
          }
        }
      }
    }
  }
  const parts = header.split(",");
  const selections = [];
  const map = /* @__PURE__ */ new Set();
  for (let i = 0; i < parts.length; ++i) {
    const part = parts[i];
    if (!part) {
      continue;
    }
    const params = part.split(";");
    if (params.length > 2) {
      throw new Error(`Invalid ${options.type} header`);
    }
    const token = params[0].toLowerCase();
    if (!token) {
      throw new Error(`Invalid ${options.type} header`);
    }
    const selection = { token, pos: i, q: 1 };
    if (preferences && lowers.has(token)) {
      selection.pref = lowers.get(token).pos;
    }
    map.add(selection.token);
    if (params.length === 2) {
      const q = params[1];
      const [key, value] = q.split("=");
      if (!value || key !== "q" && key !== "Q") {
        throw new Error(`Invalid ${options.type} header`);
      }
      const score = Number.parseFloat(value);
      if (score === 0) {
        continue;
      }
      if (Number.isFinite(score) && score <= 1 && score >= 1e-3) {
        selection.q = score;
      }
    }
    selections.push(selection);
  }
  selections.sort((a, b) => {
    if (b.q !== a.q) {
      return b.q - a.q;
    }
    if (b.pref !== a.pref) {
      if (a.pref === void 0) {
        return 1;
      }
      if (b.pref === void 0) {
        return -1;
      }
      return a.pref - b.pref;
    }
    return a.pos - b.pos;
  });
  const values = selections.map((selection) => selection.token);
  if (!preferences || !preferences.length) {
    return values;
  }
  const preferred = [];
  for (const selection of values) {
    if (selection === "*") {
      for (const [preference, value] of lowers) {
        if (!map.has(preference)) {
          preferred.push(value.orig);
        }
      }
    } else {
      const lower = selection.toLowerCase();
      if (lowers.has(lower)) {
        preferred.push(lowers.get(lower).orig);
      }
    }
  }
  return preferred;
}
function acceptLanguage(header = "", preferences) {
  return parse(header, preferences, {
    type: "accept-language",
    prefixMatch: true
  })[0] || void 0;
}

// node_modules/@opennextjs/aws/dist/core/routing/i18n/index.js
function isLocalizedPath(path2) {
  return NextConfig.i18n?.locales.includes(path2.split("/")[1].toLowerCase()) ?? false;
}
function getLocaleFromCookie(cookies) {
  const i18n = NextConfig.i18n;
  const nextLocale = cookies.NEXT_LOCALE?.toLowerCase();
  return nextLocale ? i18n?.locales.find((locale) => nextLocale === locale.toLowerCase()) : void 0;
}
function detectDomainLocale({ hostname, detectedLocale }) {
  const i18n = NextConfig.i18n;
  const domains = i18n?.domains;
  if (!domains) {
    return;
  }
  const lowercasedLocale = detectedLocale?.toLowerCase();
  for (const domain of domains) {
    const domainHostname = domain.domain.split(":", 1)[0].toLowerCase();
    if (hostname === domainHostname || lowercasedLocale === domain.defaultLocale.toLowerCase() || domain.locales?.some((locale) => lowercasedLocale === locale.toLowerCase())) {
      return domain;
    }
  }
}
function detectLocale(internalEvent, i18n) {
  const domainLocale = detectDomainLocale({
    hostname: internalEvent.headers.host
  });
  if (i18n.localeDetection === false) {
    return domainLocale?.defaultLocale ?? i18n.defaultLocale;
  }
  const cookiesLocale = getLocaleFromCookie(internalEvent.cookies);
  const preferredLocale = acceptLanguage(internalEvent.headers["accept-language"], i18n?.locales);
  debug({
    cookiesLocale,
    preferredLocale,
    defaultLocale: i18n.defaultLocale,
    domainLocale
  });
  return domainLocale?.defaultLocale ?? cookiesLocale ?? preferredLocale ?? i18n.defaultLocale;
}
function localizePath(internalEvent) {
  const i18n = NextConfig.i18n;
  if (!i18n) {
    return internalEvent.rawPath;
  }
  if (isLocalizedPath(internalEvent.rawPath)) {
    return internalEvent.rawPath;
  }
  const detectedLocale = detectLocale(internalEvent, i18n);
  return `/${detectedLocale}${internalEvent.rawPath}`;
}

// node_modules/@opennextjs/aws/dist/core/routing/queue.js
function generateShardId(rawPath, maxConcurrency, prefix) {
  let a = cyrb128(rawPath);
  let t = a += 1831565813;
  t = Math.imul(t ^ t >>> 15, t | 1);
  t ^= t + Math.imul(t ^ t >>> 7, t | 61);
  const randomFloat = ((t ^ t >>> 14) >>> 0) / 4294967296;
  const randomInt = Math.floor(randomFloat * maxConcurrency);
  return `${prefix}-${randomInt}`;
}
function generateMessageGroupId(rawPath) {
  const maxConcurrency = Number.parseInt(process.env.MAX_REVALIDATE_CONCURRENCY ?? "10");
  return generateShardId(rawPath, maxConcurrency, "revalidate");
}
function cyrb128(str) {
  let h1 = 1779033703;
  let h2 = 3144134277;
  let h3 = 1013904242;
  let h4 = 2773480762;
  for (let i = 0, k; i < str.length; i++) {
    k = str.charCodeAt(i);
    h1 = h2 ^ Math.imul(h1 ^ k, 597399067);
    h2 = h3 ^ Math.imul(h2 ^ k, 2869860233);
    h3 = h4 ^ Math.imul(h3 ^ k, 951274213);
    h4 = h1 ^ Math.imul(h4 ^ k, 2716044179);
  }
  h1 = Math.imul(h3 ^ h1 >>> 18, 597399067);
  h2 = Math.imul(h4 ^ h2 >>> 22, 2869860233);
  h3 = Math.imul(h1 ^ h3 >>> 17, 951274213);
  h4 = Math.imul(h2 ^ h4 >>> 19, 2716044179);
  h1 ^= h2 ^ h3 ^ h4, h2 ^= h1, h3 ^= h1, h4 ^= h1;
  return h1 >>> 0;
}

// node_modules/@opennextjs/aws/dist/core/routing/util.js
function constructNextUrl(baseUrl, path2) {
  const nextBasePath = NextConfig.basePath ?? "";
  const url = new URL(`${nextBasePath}${path2}`, baseUrl);
  return url.href;
}
function convertRes(res) {
  const statusCode = res.statusCode || 200;
  const headers = parseHeaders(res.getFixedHeaders());
  const isBase64Encoded = isBinaryContentType(headers["content-type"]) || !!headers["content-encoding"];
  const body = new ReadableStream3({
    pull(controller) {
      if (!res._chunks || res._chunks.length === 0) {
        controller.close();
        return;
      }
      controller.enqueue(res._chunks.shift());
    }
  });
  return {
    type: "core",
    statusCode,
    headers,
    body,
    isBase64Encoded
  };
}
function convertToQueryString(query) {
  const queryStrings = [];
  Object.entries(query).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach((entry) => queryStrings.push(`${key}=${entry}`));
    } else {
      queryStrings.push(`${key}=${value}`);
    }
  });
  return queryStrings.length > 0 ? `?${queryStrings.join("&")}` : "";
}
function convertToQuery(querystring) {
  if (!querystring)
    return {};
  const query = new URLSearchParams(querystring);
  const queryObject = {};
  for (const key of query.keys()) {
    const queries = query.getAll(key);
    queryObject[key] = queries.length > 1 ? queries : queries[0];
  }
  return queryObject;
}
function getMiddlewareMatch(middlewareManifest2, functionsManifest) {
  if (functionsManifest?.functions?.["/_middleware"]) {
    return functionsManifest.functions["/_middleware"].matchers?.map(({ regexp }) => new RegExp(regexp)) ?? [/.*/];
  }
  const rootMiddleware = middlewareManifest2.middleware["/"];
  if (!rootMiddleware?.matchers)
    return [];
  return rootMiddleware.matchers.map(({ regexp }) => new RegExp(regexp));
}
function fixCacheHeaderForHtmlPages(internalEvent, headers) {
  if (internalEvent.rawPath === "/404" || internalEvent.rawPath === "/500") {
    fixCacheControlForError(headers, internalEvent.rawPath === "/404" ? 404 : 500);
    return;
  }
  const localizedPath = localizePath(internalEvent);
  if (HtmlPages.includes(localizedPath) && !internalEvent.headers["x-middleware-prefetch"]) {
    headers[CACHE_CONTROL_HEADER] = "public, max-age=0, s-maxage=31536000, must-revalidate";
  }
}
function fixSWRCacheHeader(headers) {
  let cacheControl = headers[CACHE_CONTROL_HEADER];
  if (!cacheControl)
    return;
  if (Array.isArray(cacheControl)) {
    cacheControl = cacheControl.join(",");
  }
  if (typeof cacheControl !== "string")
    return;
  headers[CACHE_CONTROL_HEADER] = cacheControl.replace(/\bstale-while-revalidate(?!=)/, "stale-while-revalidate=2592000");
}
function addOpenNextHeader(headers) {
  if (NextConfig.poweredByHeader) {
    headers["X-OpenNext"] = "1";
  }
  if (globalThis.openNextDebug) {
    headers["X-OpenNext-Version"] = globalThis.openNextVersion;
  }
  if (process.env.OPEN_NEXT_REQUEST_ID_HEADER || globalThis.openNextDebug) {
    headers["X-OpenNext-RequestId"] = globalThis.__openNextAls.getStore()?.requestId;
  }
}
async function revalidateIfRequired(host, rawPath, headers, req) {
  if (headers[NEXTJS_CACHE_HEADER] === "STALE") {
    const internalMeta = req?.[Symbol.for("NextInternalRequestMeta")];
    const revalidateUrl = internalMeta?._nextDidRewrite ? rawPath.startsWith("/_next/data/") ? `/_next/data/${BuildId}${internalMeta?._nextRewroteUrl}.json` : internalMeta?._nextRewroteUrl : rawPath;
    try {
      const hash = (str) => crypto.createHash("md5").update(str).digest("hex");
      const lastModified = globalThis.__openNextAls.getStore()?.lastModified ?? 0;
      const eTag = `${headers.etag ?? headers.ETag ?? ""}`;
      await globalThis.queue.send({
        MessageBody: { host, url: revalidateUrl, eTag, lastModified },
        MessageDeduplicationId: hash(`${rawPath}-${lastModified}-${eTag}`),
        MessageGroupId: generateMessageGroupId(rawPath)
      });
    } catch (e) {
      error(`Failed to revalidate stale page ${rawPath}`, e);
    }
  }
}
function fixISRHeaders(headers) {
  const sMaxAgeRegex = /s-maxage=(\d+)/;
  const match = headers[CACHE_CONTROL_HEADER]?.match(sMaxAgeRegex);
  const sMaxAge = match ? Number.parseInt(match[1]) : void 0;
  if (!sMaxAge) {
    return;
  }
  if (headers[NEXTJS_CACHE_HEADER] === "REVALIDATED") {
    headers[CACHE_CONTROL_HEADER] = NO_STORE_CACHE_CONTROL;
    return;
  }
  const _lastModified = globalThis.__openNextAls.getStore()?.lastModified ?? 0;
  if (headers[NEXTJS_CACHE_HEADER] === "HIT" && _lastModified > 0) {
    debug("cache-control", headers[CACHE_CONTROL_HEADER], _lastModified, Date.now());
    if (sMaxAge && sMaxAge !== 31536e3) {
      const age = Math.round((Date.now() - _lastModified) / 1e3);
      const remainingTtl = Math.max(sMaxAge - age, 1);
      headers[CACHE_CONTROL_HEADER] = `s-maxage=${remainingTtl}, stale-while-revalidate=2592000`;
    }
  }
  if (headers[NEXTJS_CACHE_HEADER] !== "STALE")
    return;
  headers[CACHE_CONTROL_HEADER] = "s-maxage=2, stale-while-revalidate=2592000";
}
function createServerResponse(routingResult, headers, responseStream) {
  const internalEvent = routingResult.internalEvent;
  return new OpenNextNodeResponse((_headers) => {
    fixCacheHeaderForHtmlPages(internalEvent, _headers);
    fixSWRCacheHeader(_headers);
    addOpenNextHeader(_headers);
    fixISRHeaders(_headers);
  }, async (_headers) => {
    await revalidateIfRequired(internalEvent.headers.host, internalEvent.rawPath, _headers);
    await invalidateCDNOnRequest(routingResult, _headers);
  }, responseStream, headers, routingResult.rewriteStatusCode);
}
async function invalidateCDNOnRequest(params, headers) {
  const { internalEvent, resolvedRoutes, initialURL } = params;
  const initialPath = new URL(initialURL).pathname;
  const isIsrRevalidation = internalEvent.headers[ISR_HEADER] === "1";
  if (!isIsrRevalidation && headers[NEXTJS_CACHE_HEADER] === "REVALIDATED") {
    await globalThis.cdnInvalidationHandler.invalidatePaths([
      {
        initialPath,
        rawPath: internalEvent.rawPath,
        resolvedRoutes
      }
    ]);
  }
}

// node_modules/@opennextjs/aws/dist/core/routingHandler.js
init_logger();

// node_modules/@opennextjs/aws/dist/core/routing/cacheInterceptor.js
init_stream();

// node_modules/@opennextjs/aws/dist/utils/cache.js
init_logger();

// node_modules/@opennextjs/aws/dist/core/routing/cacheInterceptor.js
init_logger();
var CACHE_ONE_YEAR = 60 * 60 * 24 * 365;
var CACHE_ONE_MONTH = 60 * 60 * 24 * 30;

// node_modules/@opennextjs/aws/dist/core/routing/matcher.js
init_stream();
init_logger();

// node_modules/@opennextjs/aws/dist/core/routing/routeMatcher.js
var optionalLocalePrefixRegex = `^/(?:${RoutesManifest.locales.map((locale) => `${locale}/?`).join("|")})?`;
var optionalBasepathPrefixRegex = RoutesManifest.basePath ? `^${RoutesManifest.basePath}/?` : "^/";
var optionalPrefix = optionalLocalePrefixRegex.replace("^/", optionalBasepathPrefixRegex);
function routeMatcher(routeDefinitions) {
  const regexp = routeDefinitions.map((route) => ({
    page: route.page,
    regexp: new RegExp(route.regex.replace("^/", optionalPrefix))
  }));
  const appPathsSet = /* @__PURE__ */ new Set();
  const routePathsSet = /* @__PURE__ */ new Set();
  for (const [k, v] of Object.entries(AppPathRoutesManifest)) {
    if (k.endsWith("page")) {
      appPathsSet.add(v);
    } else if (k.endsWith("route")) {
      routePathsSet.add(v);
    }
  }
  return function matchRoute(path2) {
    const foundRoutes = regexp.filter((route) => route.regexp.test(path2));
    return foundRoutes.map((foundRoute) => {
      let routeType = "page";
      if (appPathsSet.has(foundRoute.page)) {
        routeType = "app";
      } else if (routePathsSet.has(foundRoute.page)) {
        routeType = "route";
      }
      return {
        route: foundRoute.page,
        type: routeType
      };
    });
  };
}
var staticRouteMatcher = routeMatcher([
  ...RoutesManifest.routes.static,
  ...getStaticAPIRoutes()
]);
var dynamicRouteMatcher = routeMatcher(RoutesManifest.routes.dynamic);
function getStaticAPIRoutes() {
  const createRouteDefinition = (route) => ({
    page: route,
    regex: `^${route}(?:/)?$`
  });
  const dynamicRoutePages = new Set(RoutesManifest.routes.dynamic.map(({ page }) => page));
  const pagesStaticAPIRoutes = Object.keys(PagesManifest).filter((route) => route.startsWith("/api/") && !dynamicRoutePages.has(route)).map(createRouteDefinition);
  const appPathsStaticAPIRoutes = Object.values(AppPathRoutesManifest).filter((route) => (route.startsWith("/api/") || route === "/api") && !dynamicRoutePages.has(route)).map(createRouteDefinition);
  return [...pagesStaticAPIRoutes, ...appPathsStaticAPIRoutes];
}

// node_modules/@opennextjs/aws/dist/core/routing/middleware.js
init_stream();
init_utils();
var middlewareManifest = MiddlewareManifest;
var functionsConfigManifest = FunctionsConfigManifest;
var middleMatch = getMiddlewareMatch(middlewareManifest, functionsConfigManifest);

// node_modules/@opennextjs/aws/dist/core/routingHandler.js
var MIDDLEWARE_HEADER_PREFIX = "x-middleware-response-";
var MIDDLEWARE_HEADER_PREFIX_LEN = MIDDLEWARE_HEADER_PREFIX.length;
var INTERNAL_HEADER_PREFIX = "x-opennext-";
var INTERNAL_HEADER_INITIAL_URL = `${INTERNAL_HEADER_PREFIX}initial-url`;
var INTERNAL_HEADER_LOCALE = `${INTERNAL_HEADER_PREFIX}locale`;
var INTERNAL_HEADER_RESOLVED_ROUTES = `${INTERNAL_HEADER_PREFIX}resolved-routes`;
var INTERNAL_HEADER_REWRITE_STATUS_CODE = `${INTERNAL_HEADER_PREFIX}rewrite-status-code`;
var INTERNAL_EVENT_REQUEST_ID = `${INTERNAL_HEADER_PREFIX}request-id`;

// node_modules/@opennextjs/aws/dist/core/util.js
init_logger();
import NextServer from "next/dist/server/next-server.js";

// node_modules/@opennextjs/aws/dist/core/require-hooks.js
init_logger();
var mod2 = (init_node_module(), __toCommonJS(node_module_exports));
var resolveFilename2 = mod2._resolveFilename;

// node_modules/@opennextjs/aws/dist/core/util.js
var cacheHandlerPath = __require.resolve("./cache.cjs");
var composableCacheHandlerPath = __require.resolve("./composable-cache.cjs");
var nextServer = new NextServer.default({
  conf: {
    ...NextConfig,
    // Next.js compression should be disabled because of a bug in the bundled
    // `compression` package — https://github.com/vercel/next.js/issues/11669
    compress: false,
    // By default, Next.js uses local disk to store ISR cache. We will use
    // our own cache handler to store the cache on S3.
    //#override stableIncrementalCache
    cacheHandler: cacheHandlerPath,
    cacheMaxMemorySize: 0,
    // We need to disable memory cache
    //#endOverride
    experimental: {
      ...NextConfig.experimental,
      // This uses the request.headers.host as the URL
      // https://github.com/vercel/next.js/blob/canary/packages/next/src/server/next-server.ts#L1749-L1754
      //#override trustHostHeader
      trustHostHeader: true,
      //#endOverride
      //#override composableCache
      cacheHandlers: {
        default: composableCacheHandlerPath
      }
      //#endOverride
    }
  },
  customServer: false,
  dev: false,
  dir: __dirname
});
var routesLoaded = false;
globalThis.__next_route_preloader = async (stage) => {
  if (routesLoaded) {
    return;
  }
  const thisFunction = globalThis.fnName ? globalThis.openNextConfig.functions[globalThis.fnName] : globalThis.openNextConfig.default;
  const routePreloadingBehavior = thisFunction?.routePreloadingBehavior ?? "none";
  if (routePreloadingBehavior === "none") {
    routesLoaded = true;
    return;
  }
  if (!("unstable_preloadEntries" in nextServer)) {
    debug("The current version of Next.js does not support route preloading. Skipping route preloading.");
    routesLoaded = true;
    return;
  }
  if (stage === "waitUntil" && routePreloadingBehavior === "withWaitUntil") {
    const waitUntil = globalThis.__openNextAls.getStore()?.waitUntil;
    if (!waitUntil) {
      error("You've tried to use the 'withWaitUntil' route preloading behavior, but the 'waitUntil' function is not available.");
      routesLoaded = true;
      return;
    }
    debug("Preloading entries with waitUntil");
    waitUntil?.(nextServer.unstable_preloadEntries());
    routesLoaded = true;
  } else if (stage === "start" && routePreloadingBehavior === "onStart" || stage === "warmerEvent" && routePreloadingBehavior === "onWarmerEvent" || stage === "onDemand") {
    const startTimestamp = Date.now();
    debug("Preloading entries");
    await nextServer.unstable_preloadEntries();
    debug("Preloading entries took", Date.now() - startTimestamp, "ms");
    routesLoaded = true;
  }
};
var requestHandler = (metadata) => "getRequestHandlerWithMetadata" in nextServer ? nextServer.getRequestHandlerWithMetadata(metadata) : nextServer.getRequestHandler();

// node_modules/@opennextjs/aws/dist/core/requestHandler.js
globalThis.__openNextAls = new AsyncLocalStorage();
async function openNextHandler(internalEvent, options) {
  const initialHeaders = internalEvent.headers;
  const requestId = globalThis.openNextConfig.middleware?.external ? internalEvent.headers[INTERNAL_EVENT_REQUEST_ID] : Math.random().toString(36);
  return runWithOpenNextRequestContext({
    isISRRevalidation: initialHeaders[ISR_HEADER] === "1",
    waitUntil: options?.waitUntil,
    requestId
  }, async () => {
    await globalThis.__next_route_preloader("waitUntil");
    if (initialHeaders["x-forwarded-host"]) {
      initialHeaders.host = initialHeaders["x-forwarded-host"];
    }
    debug("internalEvent", internalEvent);
    const internalHeaders = {
      initialPath: initialHeaders[INTERNAL_HEADER_INITIAL_URL] ?? internalEvent.rawPath,
      resolvedRoutes: initialHeaders[INTERNAL_HEADER_RESOLVED_ROUTES] ? JSON.parse(initialHeaders[INTERNAL_HEADER_RESOLVED_ROUTES]) : [],
      rewriteStatusCode: Number.parseInt(initialHeaders[INTERNAL_HEADER_REWRITE_STATUS_CODE])
    };
    let routingResult = {
      internalEvent,
      isExternalRewrite: false,
      origin: false,
      isISR: false,
      initialURL: internalEvent.url,
      ...internalHeaders
    };
    const headers = "type" in routingResult ? routingResult.headers : routingResult.internalEvent.headers;
    const overwrittenResponseHeaders = {};
    for (const [rawKey, value] of Object.entries(headers)) {
      if (!rawKey.startsWith(MIDDLEWARE_HEADER_PREFIX)) {
        continue;
      }
      const key = rawKey.slice(MIDDLEWARE_HEADER_PREFIX_LEN);
      if (key !== "x-middleware-set-cookie") {
        overwrittenResponseHeaders[key] = value;
      }
      headers[key] = value;
      delete headers[rawKey];
    }
    if ("isExternalRewrite" in routingResult && routingResult.isExternalRewrite === true) {
      try {
        routingResult = await globalThis.proxyExternalRequest.proxy(routingResult.internalEvent);
      } catch (e) {
        error("External request failed.", e);
        routingResult = {
          internalEvent: {
            type: "core",
            rawPath: "/500",
            method: "GET",
            headers: {},
            url: constructNextUrl(internalEvent.url, "/500"),
            query: {},
            cookies: {},
            remoteAddress: ""
          },
          // On error we need to rewrite to the 500 page which is an internal rewrite
          isExternalRewrite: false,
          isISR: false,
          origin: false,
          initialURL: internalEvent.url,
          resolvedRoutes: [{ route: "/500", type: "page" }]
        };
      }
    }
    if ("type" in routingResult) {
      if (options?.streamCreator) {
        const response = createServerResponse({
          internalEvent,
          isExternalRewrite: false,
          isISR: false,
          resolvedRoutes: [],
          origin: false,
          initialURL: internalEvent.url
        }, routingResult.headers, options.streamCreator);
        response.statusCode = routingResult.statusCode;
        response.flushHeaders();
        const [bodyToConsume, bodyToReturn] = routingResult.body.tee();
        for await (const chunk of bodyToConsume) {
          response.write(chunk);
        }
        response.end();
        routingResult.body = bodyToReturn;
      }
      return routingResult;
    }
    const preprocessedEvent = routingResult.internalEvent;
    debug("preprocessedEvent", preprocessedEvent);
    const { search, pathname, hash } = new URL(preprocessedEvent.url);
    const reqProps = {
      method: preprocessedEvent.method,
      url: `${pathname}${search}${hash}`,
      //WORKAROUND: We pass this header to the serverless function to mimic a prefetch request which will not trigger revalidation since we handle revalidation differently
      // There is 3 way we can handle revalidation:
      // 1. We could just let the revalidation go as normal, but due to race conditions the revalidation will be unreliable
      // 2. We could alter the lastModified time of our cache to make next believe that the cache is fresh, but this could cause issues with stale data since the cdn will cache the stale data as if it was fresh
      // 3. OUR CHOICE: We could pass a purpose prefetch header to the serverless function to make next believe that the request is a prefetch request and not trigger revalidation (This could potentially break in the future if next changes the behavior of prefetch requests)
      headers: {
        ...headers
      },
      body: preprocessedEvent.body,
      remoteAddress: preprocessedEvent.remoteAddress
    };
    const mergeHeadersPriority = globalThis.openNextConfig.dangerous?.headersAndCookiesPriority ? globalThis.openNextConfig.dangerous.headersAndCookiesPriority(preprocessedEvent) : "middleware";
    const store = globalThis.__openNextAls.getStore();
    if (store) {
      store.mergeHeadersPriority = mergeHeadersPriority;
    }
    const req = new IncomingMessage(reqProps);
    const res = createServerResponse(routingResult, overwrittenResponseHeaders, options?.streamCreator);
    await processRequest(req, res, routingResult);
    const { statusCode, headers: responseHeaders, isBase64Encoded, body } = convertRes(res);
    const internalResult = {
      type: internalEvent.type,
      statusCode,
      headers: responseHeaders,
      body,
      isBase64Encoded
    };
    return internalResult;
  });
}
async function processRequest(req, res, routingResult) {
  delete req.body;
  const initialURL = new URL(
    // We always assume that only the routing layer can set this header.
    routingResult.internalEvent.headers[INTERNAL_HEADER_INITIAL_URL] ?? routingResult.initialURL
  );
  let invokeStatus;
  if (routingResult.internalEvent.rawPath === "/500") {
    invokeStatus = 500;
  } else if (routingResult.internalEvent.rawPath === "/404") {
    invokeStatus = 404;
  }
  const requestMetadata = {
    isNextDataReq: routingResult.internalEvent.query.__nextDataReq === "1",
    initURL: routingResult.initialURL,
    initQuery: convertToQuery(initialURL.search),
    initProtocol: initialURL.protocol,
    defaultLocale: NextConfig.i18n?.defaultLocale,
    locale: routingResult.locale,
    middlewareInvoke: false,
    // By setting invokePath and invokeQuery we can bypass some of the routing logic in Next.js
    invokePath: routingResult.internalEvent.rawPath,
    invokeQuery: routingResult.internalEvent.query,
    // invokeStatus is only used for error pages
    invokeStatus
  };
  try {
    req.url = initialURL.pathname + convertToQueryString(routingResult.internalEvent.query);
    await requestHandler(requestMetadata)(req, res);
  } catch (e) {
    if (e.constructor.name === "NoFallbackError") {
      await handleNoFallbackError(req, res, routingResult, requestMetadata);
    } else {
      error("NextJS request failed.", e);
      await tryRenderError("500", res, routingResult.internalEvent);
    }
  }
}
async function handleNoFallbackError(req, res, routingResult, metadata, index = 1) {
  if (index >= 5) {
    await tryRenderError("500", res, routingResult.internalEvent);
    return;
  }
  if (index >= routingResult.resolvedRoutes.length) {
    await tryRenderError("404", res, routingResult.internalEvent);
    return;
  }
  try {
    await requestHandler({
      ...routingResult,
      invokeOutput: routingResult.resolvedRoutes[index].route,
      ...metadata
    })(req, res);
  } catch (e) {
    if (e.constructor.name === "NoFallbackError") {
      await handleNoFallbackError(req, res, routingResult, metadata, index + 1);
    } else {
      error("NextJS request failed.", e);
      await tryRenderError("500", res, routingResult.internalEvent);
    }
  }
}
async function tryRenderError(type, res, internalEvent) {
  try {
    const _req = new IncomingMessage({
      method: "GET",
      url: `/${type}`,
      headers: internalEvent.headers,
      body: internalEvent.body,
      remoteAddress: internalEvent.remoteAddress
    });
    const requestMetadata = {
      // By setting invokePath and invokeQuery we can bypass some of the routing logic in Next.js
      invokePath: type === "404" ? "/404" : "/500",
      invokeStatus: type === "404" ? 404 : 500,
      middlewareInvoke: false
    };
    await requestHandler(requestMetadata)(_req, res);
  } catch (e) {
    error("NextJS request failed.", e);
    res.statusCode = 500;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify({
      message: "Server failed to respond.",
      details: e
    }, null, 2));
  }
}

// node_modules/@opennextjs/aws/dist/core/resolve.js
async function resolveConverter(converter2) {
  if (typeof converter2 === "function") {
    return converter2();
  }
  const m_1 = await Promise.resolve().then(() => (init_edge(), edge_exports));
  return m_1.default;
}
async function resolveWrapper(wrapper) {
  if (typeof wrapper === "function") {
    return wrapper();
  }
  const m_1 = await Promise.resolve().then(() => (init_cloudflare_node(), cloudflare_node_exports));
  return m_1.default;
}
async function resolveTagCache(tagCache) {
  if (typeof tagCache === "function") {
    return tagCache();
  }
  const m_1 = await Promise.resolve().then(() => (init_dummy(), dummy_exports));
  return m_1.default;
}
async function resolveQueue(queue) {
  if (typeof queue === "function") {
    return queue();
  }
  const m_1 = await Promise.resolve().then(() => (init_dummy2(), dummy_exports2));
  return m_1.default;
}
async function resolveIncrementalCache(incrementalCache) {
  if (typeof incrementalCache === "function") {
    return incrementalCache();
  }
  const m_1 = await Promise.resolve().then(() => (init_dummy3(), dummy_exports3));
  return m_1.default;
}
async function resolveAssetResolver(assetResolver) {
  if (typeof assetResolver === "function") {
    return assetResolver();
  }
  const m_1 = await Promise.resolve().then(() => (init_dummy4(), dummy_exports4));
  return m_1.default;
}
async function resolveProxyRequest(proxyRequest) {
  if (typeof proxyRequest === "function") {
    return proxyRequest();
  }
  const m_1 = await Promise.resolve().then(() => (init_fetch(), fetch_exports));
  return m_1.default;
}
async function resolveCdnInvalidation(cdnInvalidation) {
  if (typeof cdnInvalidation === "function") {
    return cdnInvalidation();
  }
  const m_1 = await Promise.resolve().then(() => (init_dummy5(), dummy_exports5));
  return m_1.default;
}

// node_modules/@opennextjs/aws/dist/core/createMainHandler.js
async function createMainHandler() {
  const config = await import("./open-next.config.mjs").then((m) => m.default);
  const thisFunction = globalThis.fnName ? config.functions[globalThis.fnName] : config.default;
  globalThis.serverId = generateUniqueId();
  globalThis.openNextConfig = config;
  await globalThis.__next_route_preloader("start");
  globalThis.queue = await resolveQueue(thisFunction.override?.queue);
  globalThis.incrementalCache = await resolveIncrementalCache(thisFunction.override?.incrementalCache);
  globalThis.tagCache = await resolveTagCache(thisFunction.override?.tagCache);
  if (config.middleware?.external !== true) {
    globalThis.assetResolver = await resolveAssetResolver(globalThis.openNextConfig.middleware?.assetResolver);
  }
  globalThis.proxyExternalRequest = await resolveProxyRequest(thisFunction.override?.proxyExternalRequest);
  globalThis.cdnInvalidationHandler = await resolveCdnInvalidation(thisFunction.override?.cdnInvalidation);
  const converter2 = await resolveConverter(thisFunction.override?.converter);
  const { wrapper, name } = await resolveWrapper(thisFunction.override?.wrapper);
  debug("Using wrapper", name);
  return wrapper(openNextHandler, converter2);
}

// node_modules/@opennextjs/aws/dist/adapters/server-adapter.js
setNodeEnv();
setNextjsServerWorkingDirectory();
globalThis.internalFetch = fetch;
var handler2 = await createMainHandler();
function setNextjsServerWorkingDirectory() {
  process.chdir(__dirname);
}
export {
  handler2 as handler
};
