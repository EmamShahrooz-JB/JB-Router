# JB-Router v0.5.88 — deploy-ready bundle

This archive is a complete build of JB-Router, the router app that runs entirely on
Cloudflare Workers. To run it on your own Cloudflare account:

```bash
unzip jb-router-v0.5.88-opennext-bundle.zip -d jb-router && cd jb-router
npx wrangler secret put JWT_SECRET          # any long random string
npx wrangler secret put INITIAL_PASSWORD    # the dashboard password
npx wrangler deploy --autoconfig=false
```

The installer at https://jb-deployer.jb-router.workers.dev does exactly these steps for you,
including the assets upload and the Durable Object migration.

Everything the app stores (providers, keys, usage, settings) lives in the `RouterDatabase`
Durable Object on your own account — nothing is sent to the project maintainers.
